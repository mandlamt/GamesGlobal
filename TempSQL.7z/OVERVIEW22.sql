--USE [FleetActiv_Wesbank]
--GO
/****** Object:  StoredProcedure [dbo].[pHorizontalDetails1]    Script Date: 4/8/2020 1:51:22 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ARITHABORT OFF
SET ANSI_WARNINGS OFF
GO
--declare @ClientName varchar(50)
CREATE PROCEDURE [dbo].[pHorizontalDetails1] (@ClientName as varchar(100))

AS
					 IF OBJECT_ID('tempdb..#Temp') IS NOT NULL     --Remove temp here 
						DROP TABLE #Temp 

						IF OBJECT_ID('tempdb..#Temp1') IS NOT NULL     --Remove temp here 
						DROP TABLE #Temp1 
IF OBJECT_ID('tempdb..#Temp13') IS NOT NULL     --Remove temp here 
						DROP TABLE #Temp13 

drop table test#
drop table test1#
--exec pHorizontalDetails1 '%'
select 
          qddm_deal 'DealNumber',
    		CONVERT(numeric,aud_after) as 'ValueData',
		  FORMAT (aud_datetime, 'yyyy/MM/dd') 'aud_datetime',
		  substring(aud_after,1,2) FieldId,
		  qdqm_quote,
          isnull(drm_name, drm_longname) 'ClientName',
          NULL 'SellingDealer',
		  qddm_chassisno 'ChassisNo',
		  qdqm_type 'DealType',
		  FORMAT (qdqm_start, 'yyyy/MM/dd')  'StartDate',
		  FORMAT (qddm_termdate, 'yyyy/MM/dd') 'TermDate'--,

 into #Temp1      
 from qddm deal
            left join qdqm on qdqm_quote = qddm_fk_quote
			left join drm on drm_accno =  qdqm_fk_accno
			left join fleetaudit on aud_key1 = qddm_fk_quote
where 
drm_name like '%'+@ClientName+'%'
 and qdqm_type in ('W-MP-CPK' , 'W-SP-CPK', 'W-MP-MONTHLY', 'W-SP-MONTHLY ') 
 and aud_field = 'qdqm_vbcpkmaintsell'
 and aud_after > '0.00'
group by
          aud_datetime,
		  aud_after ,  qddm_deal,
	      qdqm_quote,
          drm_name, 
		  drm_longname,
          qddm_chassisno,
		   qdqm_type ,
		   qdqm_start,
		   qddm_termdate--,

order by

aud_datetime  ,
aud_after  

Declare @Orders Table (OrderID varchar(10),
					   Product varchar(100),
					   Quantity varchar(100),
					   Client varchar(250),
					   ChassisNo varchar(20),
					   DealType varchar(20) ,
					   StartDate varchar(20) ,
		               TermDate varchar(20)--,

	
	);

Insert Into @Orders
select  DealNumber,
        aud_datetime,
		ValueData,
		ClientName,
        ChassisNo,
		DealType,
		StartDate,
		TermDate--,

from #Temp1

group by DealNumber,aud_datetime, ValueData,DealNumber,ClientName,ChassisNo ,DealType,StartDate,TermDate
order by DealNumber,aud_datetime,ValueData;


With Orders
     As (Select ROW_NUMBER() Over (Partition By OrderID Order By OrderID  ) As RowID,*
	     From @Orders)

Select OrderID As DealNumber,
       Client AS ClientName,  
       Min(Quantity1) As CPK1,
	   Min(Product1) As CPKDate1,
       Min(Quantity2) As CPK2,
	   Min(Product2) As CPKDate2,
	   Min(Quantity3) As CPK3,
	   Min(Product3) As CPKDate3,
	   Min(Quantity4) As CPK4,
	   Min(Product4) As CPKDate4,
	   Min(Quantity5) As CPK5,
	   Min(Product5) As CPKDate5,
	   ChassisNo As ChassisNumber,
	   DealType As DealType	,
	   StartDate AS StartDate,
	   TermDate AS TermDate--,
	
	   
into test#
From (Select ROW_NUMBER() Over (Partition By OrderID Order By OrderID) As RowID,
		OrderID,
		Client,
		ChassisNo,
		DealType,
		StartDate,
	    TermDate,
		'Product' + Cast(RowID as varchar) As ProductNum,
		'Quantity' + Cast(RowID as varchar) As QuantityNum,
		Product,
		Quantity
	From Orders) As Pvt
Pivot (Min(Product)
	For ProductNum In ([Product5],[Product4], [Product3], [Product2], [Product1])) As Pvt1
Pivot (Min(Quantity)
	For QuantityNum In ([Quantity5],[Quantity4], [Quantity3], [Quantity2], [Quantity1])) As Pvt2
Group By 
       OrderID ,
	   Client,
	   ChassisNo,	
	   DealType,
	   StartDate,
	   TermDate
order by 
		CPKDate1,
		CPKDate2,
		CPKDate3,
		CPKDate4,
		CPKDate5,
		CPK1,
		CPK2,
		CPK3,
		CPK4,
		CPK5,
		DealNumber 
		;

---UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

create table #Temp13(
                       qddm_deal varchar(10),
					   ClientName varchar(100),
					   ValueData varchar(20),
					   aud_datetime varchar(20),
					   qddm_chassisno varchar(20) ,
					   qdqm_type varchar(20) ,
					   StartDate  varchar(20),
		               TermDate varchar(20)--,
					   )
insert into #Temp13(   qddm_deal,
					   ClientName ,					 
					   ValueData ,
					   aud_datetime,
					   qddm_chassisno ,
					   qdqm_type  ,
					   StartDate ,
		               TermDate )


select 	
qddm_deal ,
 isnull(drm_name, drm_longname) drm_name,
		  case when qdqm_type in ('W-SP-MONTHLY','W-MP-MONTHLY')
	        then (qdqm_mainsell / qdqm_mkms)
	        when qdqm_type in ('W-SP-UPFRONT','W-MP-UPFRONT')
	        then (qdqm_mainsell / qdqm_mkms)
	        when qdqm_type in ('W-SP-CPK','W-MP-CPK')
	        then (qdqm_vbcpkmaintsell + qdqm_vbcpktyresell) / 100
	    else 0.00 end 'ValueData',
 FORMAT (GETDATE(), 'yyyy/MM/dd') aud_datetime ,
 qddm_chassisno ,
 qdqm_type DealType,
 		   FORMAT (qdqm_start, 'yyyy/MM/dd') qdqm_start  ,
		   FORMAT (qddm_termdate, 'yyyy/MM/dd')
from qddm
left join qdqm on qddm_fk_quote = qdqm_quote
left join drm on drm_accno =  qdqm_fk_accno
where qdqm_type IN ( 'W-MP-MONTHLY', 'W-SP-MONTHLY ')
--where qdqm_type in ( 'W-SP-CPK', 'W-MP-MONTHLY', 'W-SP-MONTHLY ') 
and qddm_new = 'y'
and qddm_term != 'y'
  and (qdqm_mainsell/ qdqm_mkms) * 100> '0.00'
--------------------------gggggggggggggggggggg
--exec pHorizontalDetails1 '%'
union all

--This is for all previous restructured deals
select
 qddpr_fk_deal ,
     isnull(drm_name, drm_longname) ,


		 --case when qdqm_type in ('W-SP-MONTHLY','W-MP-MONTHLY')
	  --      then (qddpr_mainsell / qddpr_mkm)
	  --      when qdqm_type in ('W-SP-UPFRONT','W-MP-UPFRONT')
	  --      then (qddpr_mainsell / qddpr_mkm)
	  --      when qdqm_type in ('W-SP-CPK','W-MP-CPK')
	  --      --then (qddpr_vbcpkmaintsell + qdqm_vbcpktyresell) / 100
			--then (qdqm_vbcpkmaintsell + qdqm_vbcpktyresell) / 100
			----then (qddpr_xcpkmaint + qddpr_xcpkmaint) / 100
	  --     else 0.00 end 'ValueData',

	  case when qdqm_type in ('W-SP-MONTHLY','W-MP-MONTHLY')
	        then (qddpr_mainsell / qddpr_mkm)
	        when qdqm_type in ('W-SP-UPFRONT','W-MP-UPFRONT')
	        then (qddpr_mainsell / qddpr_mkm)
	        when qdqm_type in ('W-SP-CPK','W-MP-CPK')
	        --then (qddpr_vbcpkmaintsell + qdqm_vbcpktyresell) / 100
			then (qddpr_xcpkmaint + qddpr_xcpkmaint) / 100
	        else 0.00 end 'ValueData',
	        FORMAT (qddpr_date, 'yyyy/MM/dd') ,
	   
 qddm_chassisno ,
 qdqm_type ,
 		   FORMAT (qdqm_start, 'yyyy/MM/dd'),
		   FORMAT (qddm_termdate, 'yyyy/MM/dd') 


 --INTO #Temp5	
from qddpr
left join qddm on qddpr_fk_deal = qddm_deal
left join qdqm on qddm_fk_quote = qdqm_quote
left join drm on drm_accno =  qdqm_fk_accno

--where qdqm_type in ('W-SP-CPK', 'W-MP-MONTHLY', 'W-SP-MONTHLY ') 
where qdqm_type IN ('W-MP-MONTHLY', 'W-SP-MONTHLY ')
and qddm_new = 'y'
and qddm_term != 'y'
and (qddpr_mainsell/ qddpr_mkm) * 100> '0.00'
group by
		  qddpr_date,
		  qddpr_fk_deal,
	      qdqm_quote,
          drm_name, 
		  drm_longname,
          qddm_chassisno,
		   qdqm_type ,
		   qdqm_start,
		   qddm_termdate,
		   qddpr_mainsell , qddpr_mkm,qdqm_mainsell,qdqm_tkms,qddpr_xcpkmaint


order by

aud_datetime  --,-- ,
Declare @Orderss Table (OrderID varchar(10),
					   Product varchar(100),
					   Quantity varchar(100),
					   Client varchar(250),
					   --MaintSell varchar(20),
					   ChassisNo varchar(20),
					   DealType varchar(20) ,
					   StartDate varchar(20) ,
		               TermDate varchar(20)--,

	
	);

	Insert Into @Orderss
select  qddm_deal,
        aud_datetime,
		ValueData,
		ClientName,
        qddm_chassisno,
		qdqm_type,
		StartDate,
		TermDate

from #Temp13--;
group by qddm_deal,aud_datetime, ValueData,qddm_deal,ClientName,qddm_chassisno ,qdqm_type,StartDate,TermDate
order by qddm_deal,aud_datetime,ValueData;
-------MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
With Orders -----?????????????????????????????????????
     As (Select ROW_NUMBER() Over (Partition By OrderID Order By OrderID  ) As RowID,*
	     From @Orderss)

Select OrderID As DealNumber,
       Client AS ClientName,  
       Min(Quantity1) As CPK1,
	   Min(Product1) As CPKDate1,
       Min(Quantity2) As CPK2,
	   Min(Product2) As CPKDate2,
	   Min(Quantity3) As CPK3,
	   Min(Product3) As CPKDate3,
	   Min(Quantity4) As CPK4,
	   Min(Product4) As CPKDate4,
	   Min(Quantity5) As CPK5,
	   Min(Product5) As CPKDate5,
	   ChassisNo As ChassisNumber,
	   DealType As DealType	,
	   StartDate AS StartDate,
	   TermDate AS TermDate--,
	
	   --------BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB
into test1#
From (Select ROW_NUMBER() Over (Partition By OrderID Order By OrderID) As RowID,
		OrderID,
		Client,
		ChassisNo,
		DealType,
		StartDate,
	    TermDate,
		'Product' + Cast(RowID as varchar) As ProductNum,
		'Quantity' + Cast(RowID as varchar) As QuantityNum,
		Product,
		Quantity
	From Orders) As Pvt
Pivot (Min(Product)
	For ProductNum In ([Product5],[Product4], [Product3], [Product2], [Product1])) As Pvt1
Pivot (Min(Quantity)
	For QuantityNum In ([Quantity5],[Quantity4], [Quantity3], [Quantity2], [Quantity1])) As Pvt2
Group By 
        
		
		--	
       OrderID ,
	   Client,
	   ChassisNo,	
	   DealType,
	   StartDate,
	   TermDate--,

		order by 
		CPKDate1,
		CPKDate2,
		CPKDate3,
		CPKDate4,
		CPKDate5,
		CPK1,
		CPK2,
		CPK3,
		CPK4,
		CPK5,
		DealNumber 
				;													
-------nnnnnnnnnnnnnnnnnnnnnnnnnnn
--XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
create table #Temp14(
                       DealNumber varchar(10),
					   ClientName varchar(100),
					   CPK1 varchar(20),
					   CPKDate1 varchar(20),
					   CPK2 varchar(20) ,
					   CPKDate2 varchar(20) ,
					   CPK3  varchar(20),
		               CPKDate3 varchar(20),
					   CPK4 varchar(10),
					   CPKDate4 varchar(100),
					   CPK5 varchar(20),
					   CPKDate5 varchar(20),
					   ChassisNumber varchar(20) ,
					   DealType varchar(20) ,
					   StartDate  varchar(20),
		               TermDate varchar(20)--,
					   )
insert into #Temp14(   DealNumber ,
					   ClientName,
					   CPK1 ,
					   CPKDate1,
					   CPK2  ,
					   CPKDate2  ,
					   CPK3  ,
		               CPKDate3 ,
					   CPK4 ,
					   CPKDate4,
					   CPK5 ,
					   CPKDate5,
					   ChassisNumber  ,
					   DealType  ,
					   StartDate,
		               TermDate )

select  
DealNumber	,
ClientName	,
	CONVERT(numeric(18,2),CPK1) as 'CPK1',
CPKDate1,
  	CONVERT(numeric(18,2),CPK2) as 'CPK2',
CPKDate2,	
  	CONVERT(numeric(18,2),CPK3) as 'CPK3',
CPKDate3	,
	CONVERT(numeric(18,2),CPK4) as 'CPK4',
CPKDate4	,
  	CONVERT(numeric(18,2),CPK5) as 'CPK5',
CPKDate5,
ChassisNumber	,
DealType	,
StartDate	,
TermDate
from test1# 
--exec pHorizontalDetails1 'BIDVEST MCCARTHY NISSAN'
--exec pHorizontalDetails1 '%'
UNION ALL
select  
DealNumber	,
ClientName	,
RIGHT('0.'+ CONVERT(VARCHAR,CPK1),6)CPK1, 
CPKDate1,
 RIGHT('0.'+ CONVERT(VARCHAR,CPK2),6)CPK2, 
CPKDate2,	
  RIGHT('0.'+ CONVERT(VARCHAR,CPK3),6)CPK3, 
CPKDate3	,
RIGHT('0.'+ CONVERT(VARCHAR,CPK4),6)CPK4, 
CPKDate4	,
RIGHT('0.'+ CONVERT(VARCHAR,CPK5),6)CPK5, 
CPKDate5,
ChassisNumber	,
DealType	,
StartDate	,
TermDate
from test# 



select * from #Temp14
where ClientName like '%'+@ClientName+'%'
ORDER BY ClientName 
--exec pHorizontalDetails1 'BIDVEST MCCARTHY NISSAN'
--exec pHorizontalDetails1 '%'



















