declare @db varchar(50) = (select db_name());

if @db like 'FleetActiv_Wesbank%'
begin


--1 Update Debtor Transaction for deal number '0000108694' 
	select drt_gllink from drt where drt_fk_accno = '007662'
		 AND drt_gllink = '16048217'
					                           
					update drt 
					set drt_company = '12'
					where drt_gllink = '16048217'

					                           
	select drt_gllink ,* from drt where drt_fk_accno = '007662'
	   AND drt_gllink = '16048217'



--1 Update GL Transaction for deal number '0000108694'
	 select * from glt WHERE glt_ref = '0000108694' 
	  AND glt_gllink = (select drt_gllink from drt where drt_fk_accno = '007662'
	  AND drt_gllink = '16048217' )


					update glt 
					set glt_fk_accno = '121019G'
					where glt_auditno = '18005354'


					update glt 
					set glt_fk_accno = '121030G'
					where glt_auditno = '18005355'




					update glt 
					set glt_fk_accno = '121382G'
					where glt_auditno = '18005356'


					update glt 
					set glt_fk_accno = '121387'
					where glt_auditno = '18005357'




					--113081G
					update glt 
					set glt_fk_accno = '122169G'
					where glt_auditno = '18005358'


					--113500G
					update glt 
					set glt_fk_accno = '123081G'
					where glt_auditno = '18005359'

					update glt 
					set glt_fk_accno = '123500G'
					where glt_auditno = '18005360'

					--114524G
					update glt 
					set glt_fk_accno = '123818G'
					where glt_auditno = '18005361'

					update glt 
					set glt_fk_accno = '124520G'
					where glt_auditno = '18005362'

					update glt 
					set glt_fk_accno = '124524G'
					where glt_auditno = '18005363'


					update glt 
					set glt_fk_accno = '124588G'
					where glt_auditno = '18005364'

					update glt 
					set glt_fk_accno = '124588G'
					where glt_auditno = '18005365'


					update glt 
					set glt_fk_accno = '124588G'
					where glt_auditno = '18005366'


			select * from glt WHERE glt_ref = '0000108694' 
			AND glt_gllink = (select drt_gllink from drt where drt_fk_accno = '007662'
			AND drt_gllink = '16048217' )
					                           
					                           
					                           
					                           
					                           
					                           
					                           
					                           
					                           
					                           
--2 Update Debtor Transaction for deal number '0000108698' 
			select drt_gllink,* from drt where drt_fk_accno = '007662'
											   AND drt_gllink = '16048232'
					                           
					update drt 
					set drt_company = '12'
					where drt_gllink = '16048232'

					                           
			select drt_gllink ,* from drt where drt_fk_accno = '007662'
				AND drt_gllink = '16048232'
				

--2 Update GL Transaction for deal number '0000108698'
				select * from glt WHERE glt_ref = '0000108698' 
				AND glt_gllink = (select drt_gllink from drt where drt_fk_accno = '007662'
				AND drt_gllink = '16048232' )


							update glt 
							set glt_fk_accno = '121019G'
							where glt_auditno = '18005444'


							update glt 
							set glt_fk_accno = '121030G'
							where glt_auditno = '18005445'




							update glt 
							set glt_fk_accno = '121382G'
							where glt_auditno = '18005446'


							update glt 
							set glt_fk_accno = '121387'
							where glt_auditno = '18005447'





							update glt 
							set glt_fk_accno = '122169G'
							where glt_auditno = '18005448'



							update glt 
							set glt_fk_accno = '123081G'
							where glt_auditno = '18005449'

							update glt 
							set glt_fk_accno = '123500G'
							where glt_auditno = '18005450'

							--114524G
							update glt 
							set glt_fk_accno = '123818G'
							where glt_auditno = '18005451'

							update glt 
							set glt_fk_accno = '124520G'
							where glt_auditno = '18005452'

							update glt 
							set glt_fk_accno = '124524G'
							where glt_auditno = '18005453'


							update glt 
							set glt_fk_accno = '114588G'
							where glt_auditno = '18005454'

							update glt 
							set glt_fk_accno = '124588G'
							where glt_auditno = '18005454'


							update glt 
							set glt_fk_accno = '124588G'
							where glt_auditno = '18005455'


							update glt 
							set glt_fk_accno = '124588G'
							where glt_auditno = '18005456'

			select * from glt WHERE glt_ref = '0000108698' 
				AND glt_gllink = (select drt_gllink from drt where drt_fk_accno = '007662'
			    AND drt_gllink = '16048232' )
					                           
					                           
					                           
					                           
					                           
					                           
					                           
					                           
 --3 Update Debtor Transaction for deal number '0000108699' 
					select drt_gllink,* from drt where drt_fk_accno = '007662'
											   AND drt_gllink = '16048237'
					                           
					update drt 
					set drt_company = '12'
					where drt_gllink = '16048237'

					                           
					select drt_gllink ,* from drt where drt_fk_accno = '007662'
											   AND drt_gllink = '16048237'




	--3 Update GL Transaction for deal number '0000108698'
				 select * from glt WHERE glt_ref = '0000108699' 
					AND glt_gllink = (select drt_gllink from drt where drt_fk_accno = '007662'
					AND drt_gllink = '16048237' )


							update glt 
							set glt_fk_accno = '121019G'
							where glt_auditno = '18005474'


							update glt 
							set glt_fk_accno = '121030G'
							where glt_auditno = '18005475'




							update glt 
							set glt_fk_accno = '121382G'
							where glt_auditno = '18005476'


							update glt 
							set glt_fk_accno = '121387'
							where glt_auditno = '18005477'





							update glt 
							set glt_fk_accno = '122169G'
							where glt_auditno = '18005478'



							update glt 
							set glt_fk_accno = '123081G'
							where glt_auditno = '18005479'

							update glt 
							set glt_fk_accno = '123500G'
							where glt_auditno = '18005480'

							--114524G
							update glt 
							set glt_fk_accno = '123818G'
							where glt_auditno = '18005481'

							update glt 
							set glt_fk_accno = '124520G'
							where glt_auditno = '18005482'

							update glt 
							set glt_fk_accno = '124524G'
							where glt_auditno = '18005483'


							update glt 
							set glt_fk_accno = '114588G'
							where glt_auditno = '18005484'

							update glt 
							set glt_fk_accno = '124588G'
							where glt_auditno = '18005485'


							update glt 
							set glt_fk_accno = '124588G'
							where glt_auditno = '18005486'




				select * from glt WHERE glt_ref = '0000108699' 
						AND glt_gllink = (select drt_gllink from drt where drt_fk_accno = '007662'
				    	   AND drt_gllink = '16048237' )

end                          
					                           
					                           
					                           