SELECT        
      distinct 
     ([aud_seqnum])
     ,([aud_key1])
       ,[aud_key2] 
      --,qddm_odo
      ,[aud_datetime]
      ,qdqm_type
      ,qddm_inscoy
      ,qddm_fk_facaccno
      ,SUBSTRING(aud_user,9,8) as [Username]
      ,[aud_table]
      ,[aud_field]
      ,[aud_user]   
      --,[aud_key3]
      --,[aud_key4]
      --,[aud_key5]
      ,[aud_before]
      ,[aud_after]
      ,[aud_desc]   
  
  FROM [FleetAudit]

  LEFT  join suma
        on SUBSTRING(aud_user,1,8) = sum_id
  LEFT  join qddm
        on aud_key1 = qddm.qddm_deal
  left join qdqm
        on qddm_fk_quote =  qdqm_quote 
 where aud_table='qddm' 
 --and qddm_deal = '0000115477'

 order by aud_seqnum desc
 --and aud_field='qddm_odo'  
 --and qdqm_fk_accno = '015478'