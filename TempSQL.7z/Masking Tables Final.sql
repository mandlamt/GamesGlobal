truncate acb_sched 
truncate ACBFile
truncate ACBTransFileEntry
truncate [DriverImport]
truncate [drmtmp]
truncate [drstathist]
truncate [drt_histtmp]
truncate [drttmp]
truncate [fam]
truncate [fas]
truncate [fats]
truncate [fleetaudit]
truncate [fleetErrors]
truncate [FleetMail]
truncate [FleetWarnings]
truncate [FleetWebServicesLog1]
truncate [IFM_IMPORT_MAINT_AUTH]
truncate [mnd_audit]
truncate [opacc]
truncate [opacctmp]
truncate [opactmp]
truncate [opahtmp]
truncate [opaltmp]
truncate [opaptmp]
truncate [opastmp]
truncate [opattmp]
truncate [oraap_file]
truncate [ovmtmp]
truncate [qddm_BKP]
truncate [qddm_quote]
truncate [qddmbak]
truncate [qddmtmp]
truncate [qdqmtmp]
truncate [t_BI_INTERFACE_NEW_DEALS]
truncate [t_BI_INTERFACE_TERM_DEALS]
truncate [t_driverdet]
truncate [tempmaint]
truncate [UsersToRegister]
truncate [utmr]
truncate aem_tmp
truncate crcatCRMChangesAudit
truncate crmtmp
truncate [utSmsNotify]
truncate [drn]
truncate [ic_reports]
truncate ics_user_registry


select * from aem
update aem
	  set [aem_fname] = convert(varchar,aem_code) + '_aem_fname',
       [aem_sname] = convert(varchar,aem_code) + '_aem_sname',
	   [aem_wtel] = convert(varchar,aem_code) + '_wtel',
       [aem_htel] = convert(varchar,aem_code) + '_htel',
       [aem_ctel] = convert(varchar,aem_code) + '_ctel'
 select * from aem
	  
select * from crm	  
update crm
		set [crm_name] = convert(varchar,crm_accno) + '_crm_name',
		 [crm_post1] = convert(varchar,crm_accno) + '_crm_post1',
		 [crm_post2] = convert(varchar,crm_accno) + '_crm_post2',
		 [crm_post3] = convert(varchar,crm_accno) + '_crm_post3',
		 [crm_post4] = convert(varchar,crm_accno) + '_crm_post4',
		 [crm_street1] = convert(varchar,crm_accno) + '_crm_street1',
		 [crm_street2] = convert(varchar,crm_accno) + '_crm_street2',
		 [crm_street3] = convert(varchar,crm_accno) + '_crm_street3',
		 [crm_street4] = convert(varchar,crm_accno) + '_crm_street4',
		 [crm_conacc] = convert(varchar,crm_accno) + '_crm_conacc',
		 [crm_telacc] = convert(varchar,crm_accno) + '_tel',
		 [crm_faxacc] = convert(varchar,crm_accno) + '_fax',
		 [crm_conops] = convert(varchar,crm_accno) + '_crm_conops',
		 [crm_telops] = convert(varchar,crm_accno) + '_tel',
		 [crm_faxops] = convert(varchar,crm_accno) + '_fax',
		 [crm_bankname] = convert(varchar,crm_accno) + '_crm_bankname',
		 [crm_bankbrno] = crm_accno,
		 [crm_bankaccno] = convert(varchar,crm_accno) + '_crm_bankaccno', ---
		 [crm_bankaccname] = convert(varchar,crm_accno) + '_crm_bankaccname',
		 [crm_vatvendor] = '',
		 [crm_vatregno] = convert(varchar,crm_accno) + '_vat',
		 [crm_email] = convert(varchar,crm_accno) + '_crm_email',
		 [crm_accemail] = convert(varchar,crm_accno) + '_crm_accemail',
		 [crm_compreg] = convert(varchar,crm_accno) + '_crm_compreg'
select * from crm	


select * from [drcn]
update [drcn]
	  set [deliveryName] =  convert(varchar,id) + '_deliveryName',
       [deliveryAddress] =  convert(varchar,id) + '_deliveryAddress',
       [postalAddress] =  convert(varchar,id) + '_postalAddress'
      
select * from [drcn]
	  
select * from [drco]	  
update [drco]
      set [drco_desc] = convert(varchar, drco_id) + '_drco_desc', 
       [drco_vatno] = convert(varchar, drco_id) + '_drco_vatno', 
       [drco_street1] = convert(varchar, drco_id) + '_drco_street1', 
       [drco_street2] = convert(varchar, drco_id) + '_drco_street2', 
       [drco_street3] = convert(varchar, drco_id) + '_drco_street3', 
       [drco_street4] = convert(varchar, drco_id) + '_drco_street4', 
       [drco_post1] = convert(varchar, drco_id) + '_drco_post1', 
       [drco_post2] = convert(varchar, drco_id) + '_drco_post2', 
       [drco_post3] = convert(varchar, drco_id) + '_drco_post3', 
       [drco_post4] = convert(varchar, drco_id) + '_drco_post4', 
       [drco_fk_bankfincode] = drco_id, 
       [drco_bankname] = convert(varchar, drco_id) + '_bnkname', 
       [drco_bankbrno] = drco_id, 
       [drco_bankaccno] = convert(varchar, drco_id) + '_accno', 
       [drco_bankaccname] = convert(varchar, drco_id) + '_accname', 
       [drco_fk_bankacctype] = drco_id
 select * from [drco]
	  
 select * from [drco_old] 
update [drco_old]
      set [drco_desc] = drco_fk_accno
 select * from [drco_old]
 
 	  
  select * from [drcp]
update [drcp]
       set [drcp_name] = convert(varchar, drcp_fk_accno) + '_drcp_name',
       [drcp_cell] = convert(varchar, drcp_fk_accno) + '_cell',
       [drcp_mail] = convert(varchar, drcp_fk_accno) + '_mail',
       [drcp_tel] = convert(varchar, drcp_fk_accno) + '_tel',
       [drcp_fax] = convert(varchar, drcp_fk_accno) + '_fax',
       [drcp_id] = NULL,
	  -- [drcp_contactid] = drcp_fk_accno--,
     [drcp_id_nonsa] = NULL
  select * from [drcp]
  
 
   select * from [drh] 	  
update [drh]
	 set [drh_delname]  = convert(varchar, drh_docno) +  '_drh_delname',
	  [drh_deladdr]  = convert(varchar, drh_docno) +  '_drh_deladdr',
	  [drh_postaddr]  = convert(varchar, drh_docno) +  '_drh_postaddr',
	  [drh_longname]  = convert(varchar, drh_docno) +  '_drh_longname'
	 
   select * from [drh] 	
	   
	   
select * from [drinv] 	 
update [drinv]
	 set [ref]  = convert(varchar, id) +  '_ref',
	  [deliveryName]  = convert(varchar, id) +  '_deliveryName',
	  [deliveryAddress]  = convert(varchar, id) +  '_deliveryAddress',
	  [postalAddress]  = convert(varchar, id) +  '_postalAddress'
select * from [drinv] 
	
	
select * from [drinvddrd]  
update [drinvddrd]
	 set [desc]  = convert(varchar, fk_id) +  '_desc'
select * from [drinvddrd] 

	
select * from [drm] 
update [drm]
	 set [drm_name]  = convert(varchar, drm_accno) +  '_drm_name',
	  [drm_longname]  = convert(varchar, drm_accno) +  '_drm_longname',
	  [drm_post1]  = convert(varchar, drm_accno) +  '_drm_post1',
	  [drm_post2]  = convert(varchar, drm_accno) +  '_drm_post2',
	  [drm_post3]  = convert(varchar, drm_accno) +  '_drm_post3',
	  [drm_post4]  = convert(varchar, drm_accno) +  '_drm_post4',
	  [drm_street1]  = convert(varchar, drm_accno) +  '_drm_street1', 
	  [drm_street2]  = convert(varchar, drm_accno) +  '_drm_street2',
	  [drm_street3]  = convert(varchar, drm_accno) +  '_drm_street3',
	  [drm_street4]  = convert(varchar, drm_accno) +  '_drm_street4',
	  [drm_conacc]  = convert(varchar, drm_accno) +  '_drm_conacc',
	  [drm_telacc]  = convert(varchar, drm_accno) +  '_tel',
	  [drm_faxacc]  = convert(varchar, drm_accno) +  '_fax',
	  [drm_conops]  = convert(varchar, drm_accno) +  '_con',
	  [drm_telops]  = convert(varchar, drm_accno) +  '_tel',
	  [drm_faxops]  = convert(varchar, drm_accno) +  '_fax',
	  [drm_bankname]  = convert(varchar, drm_accno) +  '_drm_bankname',
	  [drm_bankbrno]  = 000000,
	  [drm_bankaccno]  = convert(varchar, drm_accno) +  '_drm_bankaccno',
	  [drm_bankaccname]  = convert(varchar, drm_accno) +  '_drm_bankaccname',
	  [drm_inscoy]  = convert(varchar, drm_accno) +  '_drm_inscoy',
	  [drm_insno]  = convert(varchar, drm_accno) +  '_drm_insno',	
	  [drm_vatno]  = '000000',
	--  [drm_selfins]  = '000000',
	  [drm_email]  = convert(varchar, drm_accno) +  '_drm_email',
	  [drm_proxyname]  = convert(varchar, drm_accno) +  '_drm_proxyname',
	  [drm_proxyidno]  = convert(varchar, drm_accno) +  '_drm_proxyidno',
	  [drm_proxytel]  = convert(varchar, drm_accno) +  '_ptel',
	  [drm_proxyfax]  = convert(varchar, drm_accno) +  '_pfax',
	  [drm_opsmail]  = convert(varchar, drm_accno) +  '_drm_opsmail',
	  [drm_compreg]  = convert(varchar, drm_accno) +  '_drm_compreg',
	  [drm_idnum]  = convert(varchar, drm_accno) +  '_drm_idnum',
	  [drm_employer]  = convert(varchar, drm_accno) +  '_drm_employer',
	  [drm_website]  = convert(varchar, drm_accno) +  '_drm_website',
	  [drm_llname]  = convert(varchar, drm_accno) +  '_drm_llname',
	  [drm_lltel]  = convert(varchar, drm_accno),
	  [drm_llpostal]  = convert(varchar, drm_accno) +  '_drm_llpostal',
	  [drm_acccell]  = convert(varchar, drm_accno) +  '_cell',
	  [drm_opscell]  = convert(varchar, drm_accno) +  '_cell'
select * from [drm] 


select * from drm_aem_fm 	 
update drm_aem_fm
	 set [drm_name]  = convert(varchar, drm_accno) +  '_drm_name',
	  [aem_name]  = convert(varchar, drm_accno) +  '_aem_name',
	  [fm_name]  = convert(varchar, drm_accno) +  '_fm_name'
select * from drm_aem_fm  


select * from [drsh] 
update [drsh]
	 set [drsh_name]  = convert(varchar, drsh_fk_accno) +  '_drsh_name',
	  [drsh_id]  = convert(varchar, drsh_fk_accno) +  '_drsh_id',
	  [drsh_street]  = convert(varchar, drsh_fk_accno) +  '_drsh_street',
	  [drsh_cellnumber]  = convert(varchar, drsh_fk_accno) +  '_cell',
	  [drsh_landlinenumber]  = convert(varchar, drsh_fk_accno) +  '_number'
select * from [drsh] 
	 
select * from [glt_info]	 
update [glt_info]
	 set [accNameInfo]  = convert(varchar, gllink) +  '_accNameInfo'
select * from [glt_info] 

select * from	[ics_users] 
update [ics_users]
	 set [name]  = convert(varchar, id) +  '_name'
select * from [ics_users]

select * from [mnd_audit]	 
update [mnd_audit]
	-- set [mndaud_respdesc]  = convert(varchar, mndaud_audno) +  '_mndaud_respdesc'
select * from [mnd_audit]

select * from [mndbr]	 
update [mndbr]
	 set [mndbr_desc]  = convert(varchar, mndbr_fk_accno) +  '_mndbr_desc'
select * from [mndbr]
	 
select * from	opah 	 
update [OdoHistory]
	 set [drm_name]  = convert(varchar, RegNo) +  '_drm_name'
select * from	opah 

select * from	opah 
update opah
	 set [opah_telno]  = convert(varchar, opah_authno) +  '_tel',
	  [opah_faxno]  = convert(varchar, opah_authno) +  '_fax',
	  [opah_contact]  = convert(varchar, opah_authno) +  '_opah_contact',
	  [opah_vnotes]  = convert(varchar, opah_authno) +  '_opah_vnotes'
select * from opah
	 
select * from opf	 
update opf
	 set [opfl_driver]  = convert(varchar, opfl_fk_lacode) +  '_opfl_driver',
	  [opfl_dstreet]  = convert(varchar, opfl_fk_lacode) +  '_opfl_dstreet',
	  [opfl_ststper]  = convert(varchar, opfl_fk_lacode) +  '_opfl_ststper',
	  [opfl_clientname]  = convert(varchar, opfl_fk_lacode) +  '_opfl_clientname',
	  [opfl_driverid]  = convert(varchar, opfl_fk_lacode) +  '_id',
	  [opf_streetname]  = convert(varchar, opfl_fk_lacode) +  '_opf_streetname',
	  [opf_dpostal]  = convert(varchar, opfl_fk_lacode) +  '_opf_dpostal',
	  [opf_dmail]  = convert(varchar, opfl_fk_lacode) +  '_opf_dmail',
	  [opf_dcell]  = convert(varchar, opfl_fk_lacode) +  '_cell',
	  [opf_dtelw]  = convert(varchar, opfl_fk_lacode) +  '_tel',
	  [opf_pmail]  = convert(varchar, opfl_fk_lacode) +  '_opf_pmail',
	  [opf_pcell]  = convert(varchar, opfl_fk_lacode) +  '_cell',
	  [opf_pstreet]  = convert(varchar, opfl_fk_lacode) +  '_opf_pstreet',
	  [opf_ppostal]  = convert(varchar, opfl_fk_lacode) +  '_opf_ppostal'
select * from opf	

	 
	 
select * from [oraap_trans]	 
update  [oraap_trans]
	 set [bankName]  = convert(varchar, fk_batchSource) +  '_bankName',
	  [bankBranch]  = convert(varchar, fk_batchSource) +  '_bankBranch',
	  [bankAccNo]  = convert(varchar, fk_batchSource) +  '_bankAccNo',
	  [bankAccName]  = convert(varchar, fk_batchSource) +  '_bankAccName'
	 
select * from [oraap_trans]
	 
select * from ovm
update ovm
	 set [ovm_regno]  = convert(varchar, ovm_fleetno) +  '_ovm_regno',	 
	  [ovm_natisno]  = '000000',
	  [ovm_chassisno]  = convert(varchar, ovm_fleetno) +  '_chassno',
	  [ovm_engineno]  = convert(varchar, ovm_fleetno) +  '_ovm_engineno',
	  [ovm_pfrom]  = convert(varchar, ovm_fleetno) +  '_no',
	  [ovm_contact]  = convert(varchar, ovm_fleetno) +  '_cont'
select * from ovm
	
select * from  qddm
update qddm
	 set [qddm_contact]  = convert(varchar, qddm_deal) +  '_qddm_contact',
	  [qddm_driver]  = convert(varchar, qddm_deal) +  '_qddm_driver',
	  [qddm_dpost]  = convert(varchar, qddm_deal) +  '_qddm_dpost',
	  [qddm_dstreet]  = convert(varchar, qddm_deal) +  '_qddm_dstreet',
	  [qddm_natisno]  = '000000',
	  [qddm_engineno]  = convert(varchar, qddm_deal) +  '_engine',
	  [qddm_chassisno]  = convert(varchar, qddm_deal) +  '_chassis',
	  [qddm_regno]  = convert(varchar, qddm_deal) +  '_reg',
	  [qddm_signby]  = convert(varchar, qddm_deal) +  '_sign',
	  [qddm_cellno]  = convert(varchar, qddm_deal) +  '_cell',
	  [qddm_htelno]  = convert(varchar, qddm_deal) +  '_tel',
	  [qddm_otelno]  = convert(varchar, qddm_deal) +  '_tel',
	  [qddm_faxno]  = convert(varchar, qddm_deal) +  '_fax',
	  [qddm_email]  = convert(varchar, qddm_deal) +  '_qddm_email'
select * from qddm
	
select * from qdqm	 
update qdqm
	 set [qdqm_uregno]  = convert(varchar, qdqm_quote) +  '_reg',
	  [qdqm_name]  = convert(varchar, qdqm_quote) +  '_qdqm_name',
	  [qdqm_contact]  = convert(varchar, qdqm_quote) +  '_qdqm_contact',
	  [qdqm_post1]  = convert(varchar, qdqm_quote) +  '_qdqm_post1',
	  [qdqm_post2]  = convert(varchar, qdqm_quote) +  '_qdqm_post2',
	 [qdqm_post3]  = convert(varchar, qdqm_quote) +  '_qdqm_post3',
	  [qdqm_post4]  = convert(varchar, qdqm_quote) +  '_qdqm_post4',
	  [qdqm_email]  = convert(varchar, qdqm_quote) +  '_qdqm_email',
	  [qdqm_faxno]  = convert(varchar, qdqm_quote) +  '_fax',
	  [qdqm_otelno]  = convert(varchar, qdqm_quote) +  '_tel',
	  [qdqm_htelno]  = convert(varchar, qdqm_quote) +  '_tel',
	  [qdqm_cellno]  = convert(varchar, qdqm_quote) +  '_cell'
select * from qdqmh
	
select * from qdqmh	 
update qdqmh
	 set [qdqmh_uregno]  = convert(varchar, qdqmh_quote) +  '_ureg',
	  [qdqmh_name]  = convert(varchar, qdqmh_quote) +  '_qdqmh_name',
	  [qdqmh_contact]  = convert(varchar, qdqmh_quote) +  '_qdqmh_contact',
	  [qdqmh_post1]  = convert(varchar, qdqmh_quote) +  '_qdqmh_post1',
	  [qdqmh_post2]  = convert(varchar, qdqmh_quote) +  '_qdqmh_post2',
	  [qdqmh_post3]  = convert(varchar, qdqmh_quote) +  '_qdqmh_post3',
	  [qdqmh_post4]  = convert(varchar, qdqmh_quote) +  '_qdqmh_post4',
	  [qdqmh_email]  = convert(varchar, qdqmh_quote) +  '_qdqmh_email',
	  [qdqmh_faxno]  = convert(varchar, qdqmh_quote) +  '_fax',
	  [qdqmh_otelno]  = convert(varchar, qdqmh_quote) +  '_tel',
	  [qdqmh_htelno]  = convert(varchar, qdqmh_quote) +  '_tel',
	  [qdqmh_cellno]  = convert(varchar, qdqmh_quote) +  '_cell'
select * from qdqmh
	
select * from  radl 
update radl
	 set [radl_lastname]  = convert(varchar, radl_staffno) +  '_lname',
	  [radl_firstname]  = convert(varchar, radl_staffno) +  '_fname',
	  
	  [radl_licno]  = '000000',	  
	  [radl_liccode]  = '000000',
	  [radl_driverid]  = '000000',
	  [radl_pdp]  = '000000',
	  [radl_postaladdr]  = '000000',	  
	  [radl_homeaddr]  = '',	  
	  [radl_workaddr]  = '', 
	  [radl_telh]  = '',	  
	  [radl_telw]  = '',	  
	  [radl_cell]  = '',
	  
	  [radl_email]  = '',
	  [radl_employer]  = '',
	  [radl_fax]  = ''
select * from  radl 
	
select * from [rmt]   
update [rmt]
	 set [rmt_payref] = convert(varchar, rmt_id) +  '_rmt_payref'
select * from [rmt]  

select * from suma  
update suma
	 set [sum_name]  = convert(varchar, sum_id) +  '_sum_name',
	  [sum_fullname]  = convert(varchar, sum_id) +  '_sum_fullname',
	  [sum_email]  = convert(varchar, sum_id) +  '_sum_email',
	  [sum_mobile_number]  = convert(varchar, sum_id) +  '_sum_mobile_number'
select * from suma 
	 
select * from utbr
update utbr
     set [utb_post1]  = convert(varchar, utb_code) +  '_utb_post1',
      [utb_post2]  = convert(varchar, utb_code) +  '_utb_post2',
       [utb_post3]  = convert(varchar, utb_code) +  '_utb_post3',
	  [utb_post4]  = convert(varchar, utb_code) +  '_utb_post4',
      [utb_street1]  = convert(varchar, utb_code) +  '_utb_street1',
	  [utb_street2]  = convert(varchar, utb_code) +  '_utb_street2',
	  [utb_street3]  = convert(varchar, utb_code) +  '_utb_street3',
	  [utb_street4]  = convert(varchar, utb_code) +  '_utb_street4',
	  [utb_coytel]  = convert(varchar, utb_code) +  '_tel',
	  [utb_coyfax]  = convert(varchar, utb_code) +  '_fax',
	  [utb_bankname]  = '000000',
	  [utb_bankbrno]  = utb_code,
	  [utb_bankaccno]  = convert(varchar, utb_code) +  '_bank',
	  [utb_bankaccname]  = convert(varchar, utb_code) +  '_baccn',
	 -- [utb_fk_bankacctype]  = '',
	  [utb_bankname2]  = '',
	  [utb_bankbrno2]  = '',
	  [utb_bankaccno2]  = '',
	  [utb_bankaccname2]  = '',
	 [utb_fk_bankacctype2]  = ''  
select * from utbr

select * from utfund
update utfund
	 set [utf_regno]  = convert(varchar, utf_code) +  '_utf_regno',
	  [utf_vatno]  = convert(varchar, utf_code) +  '_utf_vatno',
	  [utf_telno]  = convert(varchar, utf_code) +  '_utf_telno',
	  [utf_faxno]  = convert(varchar, utf_code) +  '_utf_faxno',
	  [utf_street1]  = convert(varchar, utf_code) +  '_utf_street1',
	  [utf_street2]  = convert(varchar, utf_code) +  '_utf_street2',
	  [utf_street3]  = convert(varchar, utf_code) +  '_utf_street3',
	  [utf_street4]  = convert(varchar, utf_code) +  '_utf_street4',
	  [utf_post1]  = convert(varchar, utf_code) +  '_utf_post1',
	  [utf_post2]  = convert(varchar, utf_code) +  '_utf_post2',
	  [utf_post3]  = convert(varchar, utf_code) +  '_utf_post3',
	  [utf_post4]  = convert(varchar, utf_code) +  '_utf_post4',
	  [utf_callcentre_tel]  = convert(varchar, utf_code) +  '_tel',
	  [utf_callcentre_fax]  = convert(varchar, utf_code) +  '_fax',
	  [utf_bankaccname]  = convert(varchar, utf_code) +  '_accn',
	  [utf_bankaccno]  = '',
	  [utf_bankname]  = convert(varchar, utf_code) +  '_utf_bankname',
	  [utf_bankbrno]  = utf_code,
	  [utf_opmanname]  = convert(varchar, utf_code) +  '_utf_opmanname',
	  [utf_procmanname]  = convert(varchar, utf_code) +  '_utf_procmanname',
	  [utf_procmantitle]  = convert(varchar, utf_code) +  '_utf_procmantitle',
	  [utf_maintcompany]  = '',
	  [utf_statcontname]  = convert(varchar, utf_code) +  '_utf_statcontname',
	  [utf_statconttel]  = convert(varchar, utf_code) +  '_tel',
	  [utf_statcontemail]  = convert(varchar, utf_code) +  '_utf_statcontemail--'
select * from utfund

	 
select * from	  utfundcd
update utfundcd
	 set [utfcd_telno]  = convert(varchar, utfcd_fk_type) +  '_utfcd_telno',
	  [utfcd_faxno]  = convert(varchar, utfcd_fk_type) +  '_utfcd_faxno',
	  [utfcd_cellno]  = convert(varchar, utfcd_fk_type) +  '_utfcd_cellno',
	  [utfcd_email]  = convert(varchar, utfcd_fk_type) +  '_utfcd_email',
	  [utfcd_street1]  = convert(varchar, utfcd_fk_type) +  '_utfcd_street1',
	  [utfcd_street2]  = convert(varchar, utfcd_fk_type) +  '_utfcd_street2',
	  [utfcd_street3]  = convert(varchar, utfcd_fk_type) +  '_utfcd_street3',
	  [utfcd_street4]  = convert(varchar, utfcd_fk_type) +  '_utfcd_street4',
	  [utfcd_post1]  = convert(varchar, utfcd_fk_type) +  '_utfcd_post1',
	  [utfcd_post2]  = convert(varchar, utfcd_fk_type) +  '_utfcd_post2',
	  [utfcd_post3]  = convert(varchar, utfcd_fk_type) +  '_utfcd_post3',
	  [utfcd_post4]  = convert(varchar, utfcd_fk_type) +  '_utfcd_post4'
select * from	  utfundcd

select * from	  utli
update utli
	 set [utli_name]  = convert(varchar, utli_code) +  '_utli_name',
	  [utli_add1]  = convert(varchar, utli_code) +  '_utli_add1',
	  [utli_add2]  = convert(varchar, utli_code) +  '_utli_add2',
	  [utli_add3]  = convert(varchar, utli_code) +  '_utli_add3',
	  [utli_add4]  = convert(varchar, utli_code) +  '_utli_add4',
	  [utli_telno]  = convert(varchar, utli_code) +  '_telno',
	  [utli_faxno]  = convert(varchar, utli_code) +  '_faxno'
select * from	  utli
	
select * from	  utp
update utp
	 set [utp_fullname]  = convert(varchar, utp_code) +  '_utp_fullname',
	  [utp_idno]  = convert(varchar, utp_code) +  '_utp_idno',
	  [utp_tel]  = convert(varchar, utp_code) +  '_tel',
	  [utp_fax]  = convert(varchar, utp_code) +  '_fax',
	  [utp_address]  = convert(varchar, utp_code) +  '_add',
	  [utp_postaladdr]  = convert(varchar, utp_code) +  '_paddr',
	  [utp_cell]  = convert(varchar, utp_code) +  '_cell',
	  [utp_email]  = convert(varchar, utp_code) +  '_email'
select * from utp

select * from drsh_history
update drsh_history
     set drsh_name = convert(varchar,drsh_fk_accno) + '_drsh_name',
      drsh_id =  convert(varchar,drsh_fk_accno) + '_drsh_id',
	  drsh_street = convert(varchar,drsh_fk_accno) + '_drsh_street',
	  drsh_cellnumber = convert(varchar,drsh_fk_accno) + '_Cell',
	  drsh_landlinenumber = convert(varchar,drsh_fk_accno) + '_Tel' 
select * from drsh_history
	 
select * from	[utUBERdrvs] 
update [utUBERdrvs]
set [utUBERdrvs_name] = convert(varchar, utUBERdrvs_uuid) +  '_utUBERdrvs_name'
select * from	[utUBERdrvs]

update sk
set sk_value = ''
where sk_id in (
				'certrack_service_url',
				'qdqm_profit_notify_addr',
				'ua_recipient(s)',
				'utc_10dayleave_uri',
				'utc_bankaccname',
				'utc_bankaccno',
				'utc_bankaccsname',
				'utc_bankacctype',
				'utc_bankbrno',
				'utc_bankname',
				'utc_batch_notify_addr',
				'utc_callcenter_fax',
				'utc_callcenter_tel',
				'utc_compbankcode',
				'utc_coyfax',
				'utc_coyreg',
				'utc_coytax',
				'utc_coytel',
				'utc_drdefaultemail',
				'utc_fics_notify_addr',
				'utc_opmanname',
				'utc_post1',
				'utc_post2',
				'utc_post3',
				'utc_post4',
				'utc_procmanname',
				'utc_proxy',
				'utc_proxyfax',
				'utc_proxyID',
				'utc_proxytel',
				'utc_sms_uri',
				'utc_street1',
				'utc_street2',
				'utc_street3',
				'utc_street4',
				'utc_uber_ctrack_password',
				'utc_uber_ctrack_username',
				'utc_uber_email_sender',
				'utc_uber_mix_password',
				'utc_uber_mix_username')
