INSERT INTO dbo.utSmsNotify (wNumber, fullName, cellNumber)
VALUES ('W5053463', 'Leeto Modutoane', '0658106547')
GO

INSERT INTO dbo.utSmsNotify (wNumber, fullName, cellNumber)
VALUES ('W5170338', 'Sibusiso Ndaba', '0825378244')
GO

INSERT INTO dbo.utSmsNotify (wNumber, fullName, cellNumber)
VALUES ('W5086787', 'Themba Sivate', '0815136115')
GO

INSERT INTO dbo.utSmsNotify (wNumber, fullName, cellNumber)
VALUES ('W1428696', 'Brenda Mokoko', '0835242180')
GO