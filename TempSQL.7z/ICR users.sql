
SELECT distinct(id),name username, full_name,credentials from
ics_user_credentials iuc
left join ics_user_registry iur
on iuc.id = iur.name
where credentials = 'instantcoffee'
--order by [name]
SELECT-- distinct(id),
* from --,name, full_name,confirmed from
ics_user_credentials 
where id = 'akachwee'
SELECT * from
ics_user_registry
name
SELECT * from ics_users  id