select drm_email, * from drm

 select  * from drt

 update drm
 set drm_email = 'mmphahlele1@wesbank.co.za'

 select * from sk
 where sk_id like '%bill%'

select ( case when ( dbo.fn_IsAutoStatementRunActive( ) > 0) then 'AUTO STATEMENT RUN ACTIVE - YES' else 'AUTO STATEMENT RUN ACTIVE - NO' end )
select ( case when ( dbo.fn_IsAutoStatementRunDue( ) > 0 ) then 'AUTO STATEMENT RUN DUE - YES' else 'AUTO STATEMENT RUN DUE - NO' end )

  select cal_scheddate, * from FleetBatchCalendar
  order by 1 desc

  



 update FleetBatchCalendar
 set cal_scheddate = '2019-12-11'
 where cal_batchid = 108

  update FleetBatchCalendar
 set cal_scheddate = '2019-12-11'
 where cal_batchid = 107


  update FleetBatchCalendar
 set cal_rundatetime = ' 2019-12-08 00:00:00.000'
 where cal_batchid = 108

  update FleetBatchCalendar
 set cal_rundatetime = ' 2019-12-08 00:00:00.000'
 where cal_batchid = 107



  update FleetBatchCalendar
 set cal_completed = '1'
 where cal_batchid = 88

  update FleetBatchCalendar
 set cal_fk_runuserid = '5085'
 where cal_batchid = 88

 select count (*) from fleetmail
  where attachment like '%AutoGen%'
 order by 1 desc





  select * from fleetmail
  where attachment like '%AutoGen%'
 order by 1 desc
 

 update fleetmail
 set sent = '0'
 where attachment like '%AutoGen%'


 Delete from fleetmail
where attachment like '%AutoGen%'
 ----order by 1 desc

 select * from sk where sk_value like '%statement%'