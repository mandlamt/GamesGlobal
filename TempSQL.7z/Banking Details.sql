select aud_table,
aud_field,
aud_user,
sum_fullname,
aud_datetime,
aud_key1,
aud_before,
aud_after,
aud_desc
from FleetAudit
left join suma on sum_name = replace(replace(aud_user,'WESBANK\',''), 'WSBEXT\','')
where aud_key1 = '010910'
and aud_field = 'drm_bankaccno'