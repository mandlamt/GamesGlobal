
USE [FleetActiv_Wesbank]
GO

select qddm_deal 'Deal No',
  	   qddm_fleetno 'Fleet No',
       isnull(drm_name, drm_longname) 'Debtor Name',
       drco_desc 'Cost Centre',
       qddm_regno 'Registration Number',
	   qdqm_type 'Contract Type',
       qdqm_fk_man+qdqm_fk_mod+qdqm_fk_var 'MM_code',
       bvmm_name 'Model Name',
       bvvm_desc 'Vehicle Description',
	   utbvc_desc 'Vehicle Category Desc',
       opah_odo 'Odometer Reading',
       qdqm_nu 'New / Used',
       (select case when (qddm_new = 'Y' and qddm_term != 'Y') 
       then 'ACTIVE' when (qddm_new = 'Y' and qddm_term = 'Y') 
       then 'TERM' else 'OTHER' end from qddm where qddm_deal = deal.qddm_deal)  as 'Deal Status',
       convert(varchar,qdqm_period) 'Period',
       convert(varchar,qdqm_tkms) 'Total_Kilometers',
       --convert(varchar,qddm_regdate,110) 'Registration Date',
       --convert(varchar,qdqm_uregdate,110) 'Used Registration Date',
	    case when qdqm_nu = 'N' then qdqm_uregdate
        else qddm_regdate end 'Date of First Reg',

       convert(varchar,qddm_termdate,110) 'Termination Date',
       qddm_origretail 'Original Retail',
       qdqm_fk_group 'Maintenance Group',
       convert(varchar,opah_authno) ' Authorisation Number',
       opah_authby 'Authorised By',
       convert(varchar,opah_udate) ' Updated Authorisation Date',
       convert(varchar,opah_authdate,110) 'Authorisation Date',
       convert(varchar,opah_fk_accno) 'Creditor Account Number',
       crm_name 'Creditor Name',
       opah_dnotes 'Profile Notes',
       opah_job_card_no 'Job Card Number',
       convert(varchar,opah_invdate,110) 'Invoice Date',
       opah_gllink 'GL Link',
       -------------------
        case when opah_month is null then (cast(datepart(yyyy,opah_authdate) as varchar(4))+''+right('00' + cast(datepart(mm,opah_authdate) as varchar(2)),2))
        else opah_month end 'Posting Month',
       -------------------
       opah_month 'GL Month',
       convert(varchar,opah_udate,110) 'Update Date',
       opah_vnotes 'General Notes',
       opah_rebillinv 'Rebill Invoice Number',
       opah_orderno 'Customer Order Number',
       upper(pft_cat) 'Category',
       upper(opap_desc) 'Profile Description',
       Work_Desc 'Work Description',
       Price 'Price',
       [Discount Percentage] 'Dicsount Percentage',
       [Discount Amount] 'Discount Amount',
       Qty 'Quantity',
       Invoice_Amount,
       [Approved Amount] 'Approved Amount',
       [Client Rebill Amount] 'Client Rebill Amount',
       [Reject Reason] 'Rejected Reason',
       Total 'Total',
       Type 'Work Type',
       status 'Status Code',
       statusDesc 'Status Desc',
	  (select case when opah_gllink is not null 
       then 'CLOSED'
	   when opah_limit_override_reqdate is not null
	   then 'LIMIT'
	   when (opah_gllink is null and opah_limit_override_reqdate is null)
	   then 'OPEN'
	   else 'Other' end as 'AuthStatus'
	   from opah
	   where opah_authno = auth.opah_authno) as 'Status'

from opah auth
left join opap on opah_authno = opap_fk_authno
left join (
                  select opas_fk_authno authNo,
                           pfp_desc Work_Desc, 
                           opas_price Price,
                           opas_invoice Invoice_Amount,
                           opas_discp 'Discount Percentage',
                           opas_disca 'Discount Amount',
                           opas_qty qty,
                           opas_approve 'Approved Amount',
                           opas_client 'Client Rebill Amount',
                           utrc_desc 'Reject Reason',
                           opas_total Total,
                           'Spares' Type,
                           opas_fk_code profile_Code
                  from opas 
                  left join pfp on pfp_partno = opas_fk_partno
                  left join utrc on opas_rejc = utrc_code
                  union all
                  select opac_fk_authno authNo,
                           pfc_desc Work_Desc, 
                           opac_price Price,
                           opac_invoice Invoice_Amount,
                           opac_discp 'Discount Percentage',
                           opac_disca 'Discount Amount',
                           opac_units qty,
                           opac_approve 'Approved Amount',
                           opac_client 'Client Rebill Amount',
                           utrc_desc 'Reject Reason',
                           opac_total Total, 
                           'Consumables' Type,
                           opac_fk_code Profile_Code
                  from opac 
                  left join pfc on pfc_code = opac_fk_ccode
                  left join utrc on opac_rejc = utrc_code
                  union all
                  select opal_fk_authno authNo,
                           pfl_desc Work_Desc, 
                           opal_price Price,
                           opal_invoice Invoice_Amount,
                           opal_discp 'Discount Percentage',
                           opal_disca 'Discount Amount',
                           opal_units qty,
                           opal_approve 'Approved Amount',
                           opal_client 'Client Rebill Amount',
                           utrc_desc 'Reject Reason',
                           opal_total Total, 
                           'Labour' Type,
                           opal_fk_code Profile_Code
                  from opal 
                  left join pfl on pfl_fk_groupid = opal_fk_group and pfl_code = opal_fk_lcode
                  left join utrc on opal_rejc = utrc_code
                  union all
                  select opat_fk_authno authNo,
                           bvtm_desc Work_Desc, 
                           opat_price Price,
                           opat_invoice Invoice_Amount,
                           opat_discp 'Discount Percentage',
                           opat_disca 'Discount Amount',
                           opat_qty qty,
                           opat_approve 'Approved Amount',
                           opat_client 'Client Rebill Amount',
                           utrc_desc 'Reject Reason',
                           opat_total Total, 
                           'Tyres' Type,
                           opat_fk_code Profile_Code
                  from opat 
left join (select bvtm_tyrecode, bvtm_fk_man, bvtm_desc, bvtm_tyresize from bvtm) tyres on bvtm_tyrecode = opat_fk_tyrecode
left join utrc on opat_rejc = utrc_code) maintenance on (maintenance.authNo = opap_fk_authno and Profile_Code = opap_fk_code)
left join crm on crm_accno = opah_fk_accno
left join qddm deal on qddm_deal = opah_fk_dealno
left join qdqm on qddm_fk_quote = qdqm_quote
left join drm on drm_accno = qdqm_fk_accno
left join drco on drco_id = qddm_custcc
left join bvvm on qdqm_fk_man = bvvm_fk_man and qdqm_fk_mod = bvvm_fk_mod and qdqm_fk_var = bvvm_var
left join bvmm on bvvm_fk_man = bvmm_man
left join bvmom on bvvm_fk_man = bvmom_fk_man and bvvm_fk_mod =bvmom_mod
left join pft on pft_code = opap_fk_code
left join utbvc on utbvc_code = bvvm_cat
left join authStatus on opah_status = authStatus.status
where opah_authdate >= '2019-11-01' and opah_authdate <= '2020-04-28'
and (drm_name like '%shoprite%' or drm_accno like '%01547%')
and qdqm_type in (select dtc_fk_dt
                  from dtc
                 where dtc_comp = 'maintenance.mm')
order by opah_authno


--select distinct(drm_name) from
--drm
--order by drm_name
--where drm_name like '%shoprite%'

--select  qddm_deal 'Deal Number',
--		case when qdqm_nu = 'Y' then 'NEW' 
--		when qdqm_nu = 'N' then 'USED' else 'OTHER' 
--		end 'New / Used',
--		qddm_regno 'Registration No',
--		drm_accno 'Client Account No',
--		isnull(drm_name, drm_longname) 'Client Name',
--		drco_desc 'Customer Cost Centre',
--		qdqm_type 'Contract Type',
--		bvvm_fk_man+bvvm_fk_mod+bvvm_var 'MM Code',
--		bvmm_name+' '+bvvm_desc 'Vehicle_Description',
--		bvmm_name 'Manufacturer',
--		bvmom_desc 'Model',
--		upper(utbvc_desc) 'Vehicle Category Name',
--		qddm_chassisno 'Chassis No',
--		qdqm_start 'Contract Start Date',
--		qddm_termdate 'Contract Term Date',
--    	case when qdqm_nu = 'N' then qdqm_uregdate
--		else qddm_regdate end 'Date of First Reg',
--		qdqm_period - qddm_billcount 'Months Remaining',
--		qddm_numinst 'Months Billed',
--		qddm_billcount 'Current Age', 
--		qdqm_period 'Contract Period',
--		qddm_delodo 'Actual Take on Odo',
--		qdqm_mkms 'Contract Ave Monthly Km',		
--		case when qdqm_tkms = 0 then 999999
--		else qdqm_tkms end 'End Contract Km',
--		((qdqm_period - qddm_billcount) * (nullif(qddm_odo,0)-qddm_delodo) / nullif(qddm_billcount,0))+ qddm_odo 'Not to Exceed KMS',
--		qddm_odo 'Current ODO',
--		qddm_ododate 'Current ODO Date',
--    	case when qdqm_nu = 'N' then datediff(month,qdqm_uregdate, GETDATE())
--		else datediff(month,qddm_regdate, getdate()) end 'Actual Vehicle Age',
--		(nullif(qddm_odo,0)-qddm_delodo) / nullif(qddm_billcount,0) 'Actual AVG KMS Run',
--		case when qdqm_mkms = 0 then 'N/A'
--		when ((nullif(qddm_odo,0)-qddm_delodo) / nullif(qddm_billcount,0))>= qdqm_mkms then 'OVER'
--		else 'UNDER' end 'Over / Under Contract'
--from qddm
--left join qdqm quote on qddm_fk_quote = qdqm_quote
--left join drco on drco_id = qddm_custcc
--left join drm on drm_accno =  qdqm_fk_accno
--left join bvvm on qdqm_fk_man = bvvm_fk_man and qdqm_fk_mod = bvvm_fk_mod and qdqm_fk_var = bvvm_var
--left join bvmm on bvvm_fk_man = bvmm_man
--left join bvmom on bvvm_fk_man = bvmom_fk_man and bvvm_fk_mod =bvmom_mod
--left join utbvc on utbvc_code = bvvm_cat
--where qddm_new = 'y'
--and qddm_term != 'y'
--and isnull(drm_name, drm_longname) like '%shoprite%'-- '%'+ @CustomerName + '%'--'%shoprite%'