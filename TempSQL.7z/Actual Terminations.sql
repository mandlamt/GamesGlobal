--BEGIN TRAN

select	qdqm_fk_branch 'Branch',

        sum_name 'User Code',
        sum_fullname 'User Name' ,

		qddterm.qddte_fk_deal 'Deal No',
		qdqm_type 'Deal Type',
	    aem.aem_fname+' '+aem.aem_sname 'Account Executive Name',
	    cmm.aem_fname+' '+cmm.aem_sname 'Corporate Marketer Name',
	    drm.drm_fk_regionid 'Region Name',
		drm_name 'Debtor Name',
		drm_longname 'Debtor Long Name',
		drco.drco_desc 'Debtor Cost Centre',
		bvvm_cat 'Cat',
		(bvmm_name+' '+bvvm_desc) 'Replaced Y/N',
		qddterm.qddte_reason 'Reason',
		(bvmm.bvmm_name+' '+bvvm.bvvm_desc) 'Vehicle Description',
		qddm.qddm_regno 'Reg No',
		qddm.qddm_chassisno 'Chassis No',
		qddm.qddm_engineno 'Engine No',
		qddm.qddm_serialno 'Serial No',
		(qdqm_fk_man+qdqm_fk_mod+qdqm_fk_var) 'MM Code',
		qdqm_basetot 'Base Tot (F)',
		qdqm_bvat 'Base VAT (F)',
		(select qdqm_basetot - qdqm_bvat from qdqm where qdqm_quote = quote.qdqm_quote) 'Base Tot (F) ex VAT',
		qddm.qddm_deptd 'Dep To Date',
		((select qdqm_basetot - qdqm_bvat from qdqm where qdqm_quote = quote.qdqm_quote) - isnull((select qddm_deptd from qddm where qddm.qddm_fk_quote = qdqm_quote),0)) 'CARRYING AMT',
		qddterm.qddte_balance 'Cap Balance',
		qdqm_rvd 'Deal RV',
		qddterm.qddte_maininc 'Main Inc',
		(dbo.fn_GetDealMaintenanceTotal( qddm.qddm_deal, 'AppExp' )) 'Main Approval',
		(dbo.fn_GetDealMaintenanceTotal( qddm.qddm_deal, 'AuthExp' )) 'Main Authorised',
		(dbo.fn_GetDealMaintenanceTotal( qddm.qddm_deal, 'AppRbl' )) 'Rebill',
		(qddm.qddm_mainsell - (dbo.fn_GetDealMaintenanceTotal( qddm.qddm_deal, 'AppExp' )) - (dbo.fn_GetDealMaintenanceTotal( qddm.qddm_deal, 'AuthExp' )) + (dbo.fn_GetDealMaintenanceTotal( qddm.qddm_deal, 'AppRbl' ))) 'Fund Balance',
		qdqm_period 'Original Months',
		((datediff( month, qdqm_start, getdate() ) ) + isnull( qdqm_uage, 0 )) 'Months Run',
		(((datediff( month, qdqm_start, getdate() ) ) + isnull( qdqm_uage, 0 ))*100/qdqm_period) '% Variance',
		qddterm.qddte_gllink 'GL Link',
		qddterm.qddte_udate 'User Date & Time' 
from qddterm qddterm 
left join qddm qddm on qddterm.qddte_fk_deal=qddm.qddm_deal 
left join qdqm quote on qddm.qddm_fk_quote=qdqm_quote 
left join drm drm on drm_accno = qdqm_fk_accno
left join bvvm on qdqm_fk_man=bvvm_fk_man and qdqm_fk_mod=bvvm_fk_mod and qdqm_fk_var=bvvm_var 
left join bvmm on bvvm_fk_man=bvmm_man 
left join aem aem on aem.aem_code = drm.drm_fk_aes 
left join suma
on suma.sum_id = qddte_unum --qdqm_actrequestuser
left join aem cmm on cmm.aem_code = drm.drm_fk_ae 
left join drco on drco.drco_id = qddm_custcc
where ((qddterm.qddte_udate>= '2019-11-01') 
and (qddterm.qddte_udate<='2019-11-30'))
order by sum_fullname



--select * from qddterm
--order by qddte_date desc
--1997-01-31 00:00:00.000
--FORMAT (qddterm.qddte_udate, 'm-d-yyyy')

--ROLLBACK