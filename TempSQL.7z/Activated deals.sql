select qddm_deal 'Deal No',
       sum_name 'User Code',
       sum_fullname 'User Name' ,
       qddm_newdate 'Act. Date',
       qdqm_name 'Name',
       qdqm_type 'Deal Type',
       qddm_regno 'Reg No',
       (bvmm_name+' '+bvvm_desc) 'Vehicle Description',
       qdqm_period 'Period',
       qdqm_tkms 'Kms Tot',
       qdqm_basetot 'Base Tot (F)',
       qdqm_basetotsell 'Base Tot (C)',
       qdqm_rvd 'Deal RV',
       qdqm_mainsell 'Main (C)',
       --qddm_newdate 'Act. Date',
       aem_fk_branchid 'Branch',
       (aem_fname +' '+aem_sname) 'Account Executive Name',
       qdqm_clientpm 'Deal Rate',
       (select sum (qdse_sell) from qdse where qdse_fk_code in ('AF','AF1') and qdse_fk_quote = qddm_fk_quote) 'ADM_Fee',
       qdqm_fk_replaced 'Replaced',
       crm_accno 'Acc No',
       crm_name 'Creditor Name',
       qddm_invref 'Creditor Invoice Number',
       getdate() as today
  from qddm
 left join qdqm on qddm_fk_quote = qdqm_quote
 left join crm on qddm_fk_supplier = crm_accno
  left join suma
 on suma.sum_id = qdqm_actrequestuser
 left join aem on qdqm_ae = aem_code
 left join bvvm on qdqm_fk_man = bvvm_fk_man and qdqm_fk_mod = bvvm_fk_mod and qdqm_fk_var = bvvm_var
 left join bvmm on bvvm_fk_man = bvmm_man
 where --((qdqm_basetotsell > 100)) and 
 (qddm_newdate >= '2019-11-01' and qddm_newdate <= '2019-11-30' )
 
 
 qdqm_actrequestuser
NULL
 qdqm_actauthuser	qdqm_actauthappr2	qdqm_actauthuser2
NULL	NULL	NULL
 qdqm_deactauthuser	qdqm_deactauthrequest	qdqm_deactrequestuser
NULL	NULL	NULL
qdqm_resauthuser
NULL
qdqm_resroecauthrequestuser
NULL
qdqm_resroecauthuser
NULL
qdqm_roecauthuser
NULL
qdqm_roecauthrequestuser
NULL
qdqm_tyresauthrequestuser
NULL
qdqm_tyresauthuser
NULL
qdqm_maintauthuser
NULL
qdqm_rvauthuser
NULL
qdqm_rvauthrequestuser	qdqm_maintauthrequestuser	qdqm_tyresauthrequestuser
NULL	NULL	NULL

 select top 10000  qdqm_actrequestuser,* from qdqm
 order by qdqm_create desc
 
 
 
 
 
select   
qdqm_create 'Create Date',
qdqm_fk_accno,
drm_name 'Debtor_Name',
qdqm_quote 'Quote_Number',
sum_name 'User Code',
sum_fullname 'User Name'   from 
qdqm
left join drm drm 
on drm_accno = qdqm_fk_accno
left join qddm 
on qddm_fk_quote = qdqm_quote
left join suma
on suma.sum_id = qdqm_actrequestuser
where (qdqm_create >= '2019-11-01') and  (qdqm_create <='2019-11-30')
order by qdqm.qdqm_create desc
 