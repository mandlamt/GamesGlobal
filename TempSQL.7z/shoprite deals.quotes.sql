select
qddm_deal as 'deal number',
 qdqm_quote 'Quote Number',
       qdqm_fk_branch 'Branch',
       qdqm_create 'Create_Date',
	   case when qdqm_nu = 'Y' then 'NEW' 
	   when qdqm_nu = 'N' then 'USED' else 'OTHER' 
	   end 'New / Used',
	   drm_accno 'Client Account No',
	   isnull(drm_name, drm_longname) 'Client Name',
	   drco_desc 'Cost Centre',
	   qdqm_type 'Contract Type',
	   bvvm_fk_man+bvvm_fk_mod+bvvm_var 'MM Code',
	   bvvm_cat 'Vehicle Category',
	   qdqm_start 'Start Date',
	   bvmm_name+' '+bvvm_desc 'Vehicle_Description',
	   bvmm_name 'Manufacturer',
	   bvmom_desc 'Model',
	   qdqm_uregno 'Used Reg Number',
	   qdqm_period 'Contract Period',
	   qdqm_uregdate 'Used Date of First Reg',
	   qdqm_tkms 'Contract Km',
	   qdqm_mkms 'Contract Ave Monthly Km',
	   qdqm_uodometer 'Used Take on Odo',
	   round(qdqm_uodometer+qdqm_tkms,0) 'Used End Kilometers',
	   round(qdqm_basetotsell,2) 'Base Total Ex Vat',
	   round(qdqm_baseprice,2) 'Retail',
	   round(qdqm_accsell,2) 'Total Accessories',
	   case when qdqm_nu = 'Y' then round((nullif(qdqm_rvd,0)/nullif(qdqm_baseprice,0) * 100),2)
	   when qdqm_nu = 'N' then round((nullif(qdqm_rvd,0)/nullif(qdqm_ubp,0) * 100),2) else '0' 
	   end 'RV %',
	   round(qdqm_rvd,2) 'RV VALUE',
	   qdqm_clienttip 'INT Rate',
	   isnull(qdqm_mainsell,0) 'Total Maintenance per Month',
	   isnull(qdqm_mainsell,0) - isnull(qdqm_mainselltyres,0) 'Maint per mnth',
	   qdqm_mainselltyres ' Tyres per mnth',
	   case when qdqm_tyres = '1' then 'Y'
			when qdqm_tyres = '0' then 'N' else 'None' end 'Tyres Y/N',
	   qdqm_tqtyf 'Front Tyres Qty',
	   qdqm_tqtyr 'Rear Tyre Qty',
	   qdqm_acccost 'Accessories - Cost',
	   qdqm_accsell 'Accessories - Sell',
	   qdqm_ivat 'Input VAT',
  	   qdqm_licsell ' Licence Fee',
  	   qdqm_sercost 'Services - Cost',
	   qdqm_sersell 'Services - Sell',
	   qdqm_finsell 'Current Fin Rental (Ex VAT)',
	   qdqm_mvatsell 'VAT',
	   qdqm_mtotsell 'Rental Total Inc Vat',
	   qdqm_xcpkrv + qdqm_xcpkmaint 'Excess Cpk  (RV + Maint)',
	   qdqm_xcpkrv 'RV Excess c/km',
	   qdqm_xcpkmaint 'Maintenance Excess c/km',
       isnull([qdqm_tqtyf],0) + isnull([qdqm_tqtyr],0) 'Budget Tyre Quantity'

from qdqm
left join drm on drm_accno =  qdqm_fk_accno
left join drco on (drco_fk_accno = qdqm_fk_accno and drco_id = qdqm_custcc)
left join bvvm on qdqm_fk_man = bvvm_fk_man and qdqm_fk_mod = bvvm_fk_mod and qdqm_fk_var = bvvm_var
left join bvmm on bvvm_fk_man = bvmm_man
left join bvmom on bvvm_fk_man = bvmom_fk_man and bvvm_fk_mod =bvmom_mod
left join qddm on qddm.qddm_fk_quote = qdqm.qdqm_quote


where drm_accno = '015478'
order by qddm_deal desc

