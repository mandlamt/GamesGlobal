


declare @db varchar(50) = (select db_name())


if @db like 'FleetActiv_Imperial%'
--declare @db varchar(50) = (select db_name())


--if @db like 'FleetActiv_Imperial%'
begin

			select * from drt_drt_hist_cc
			where  drt_gllink IN 
			(
				
				'89165714',
				'89193079',
				'89578399',
                '89578389',
                '89578388'--,
			
			)

			SELECT * from 
			drt_drt_hist_cc
			where drt_fk_accno = '011428' and drt_gllink = '89578399'
			
			--select * from Func_DR_Linked_Transactions('87941145')

			--select * from DebtorTranLink
			--where Master_AuditNo = '87941153'
			--or Detail_AuditNo = '87941153'


			--select * from DebtorTranLink
			--where Detail_AuditNo = '87941153'

			--select * from crt
			--where crt_fk_accno = '011428'

			--select * from drt
			--where drt_gllink = '89578399'


----------------------------------------
	  --      select * from crt
			--where crt_fk_accno = '011428'
			
			--select * from drt_hist
			--where drt_gllink = '89578399'
			
			select * from drt_hist
			where drt_fk_accno = '011428' 
			order by drt_auditno desc
			
/*
011428   RECEIPT  87941153 89578399
011428   REV REC  87941146 89578389
011428   REV REC  87941145 89578388
		*/
------------------------------------------	
/*87941153
87941146
87941145
==
89578399
89578389
89578388

===
87941153
87941145
87941146

*/			

			select * from drt_hist
			where drt_ref = 'TSHEOLA DINARE TOURS'			
			order by drt_auditno desc	

			select * from drt_drt_hist_cc
			where drt_ref = 'TSHEOLA DINARE TOURS'			
			order by drt_auditno desc	
			
			--select * from drt_drt_hist_cc
			--where drt_ref = 'X3 FIX CORRE'			
			--order by drt_auditno desc
			
			--

			select * from DebtorTranLink
			where Master_AuditNo like '87941146' or 
			Detail_AuditNo like '87941146'
		
		
		
			select * from Func_DR_Linked_Transactions('87941145') ORDER by drt_auditno asc



			select * from DebtorTranLink
			where Master_AuditNo like '87941153' or 
			Detail_AuditNo like '87941153'
			
		 --   select * from crt
			--where crt_fk_accno = '011428'
			
			
			
			--select * from drt_drt_hist_cc
			--where drt_fk_accno = '011428' and 
			--drt_gllink like '89578388'
			
			----------------------------------------------87792839  87941145 87781491
			
			----select * from Func_DR_Linked_Transactions('87792839')--44.63
			
			
   --         drt_auditno
   --         87792839
   --         87941146
			
			----select * from DebtorTranLink
			----where Master_AuditNo like '87792839' or 
			----Detail_AuditNo like '87792839'
			
		 ----  --87941146
		
		
		
			
		 --   select * from crt
			--where crt_fk_accno = '011428'



   ----         select * from drt_drt_hist_cc
			----where drt_fk_accno = '011428'		
			------order by drt_auditno desc	
			----and drt_gllink = '89578399'


            select * from drt_drt_hist_cc
			where drt_fk_accno = '011428'		
			order by drt_auditno desc	
			--and drt_gllink = '89578399'
			
	------87941153 87941146 87941145
	------87792839 87941146   nbnbnbnbnbnbnb
			
			
			
   --         select * from DebtorTranLink
			--where Master_AuditNo = '87941153'
			--or Detail_AuditNo = '87941153'
			
	----------------------
	
	 
			--UPDATE drt
			--SET drt_alloc = 0-- 'N'
			--where drt_auditno = ''
			
			
			----select * from DebtorTranLink
			----where Master_AuditNo like '%879415%' or 
			----Detail_AuditNo like '87792839'
		
			
			---------------

			
--87781491
--87792839
--87941145
--87941146
--87941153
----------------------------------------
--89165714
--89193079
--89578388
--89578389
--89578399
			

			

			
		 
			
			

			
			
			
			
			--SELECT * from 
			--drt_drt_hist_cc 
			
end





---------------------------------------------------------------------------------------------------------
--declare @db varchar(100) = (select db_name());
declare @auditno varchar(10);
declare @drtcnt int = 0;
declare @drthistcnt int = 0;
declare @counter int = 0;

if @db like 'FleetActiv_Imperial%'
begin
	set nocount on
	declare @auditnos table ( linkno varchar(10) )
	
	



insert into @auditnos select '87941145';
insert into @auditnos select '87941146';
insert into @auditnos select '87941153';
insert into @auditnos select '87781491';
insert into @auditnos select '87792839'	
	
	--insert into @auditnos select '89165714';
	--insert into @auditnos select '89193079';
	--insert into @auditnos select '89578388';
	--insert into @auditnos select '89578389';
	--insert into @auditnos select '89578399';	
	
	--insert into @auditnos select '40419401';
	--insert into @auditnos select '87941153';D
	--insert into @auditnos select '87941146';D
	--insert into @auditnos select '87941145';D
	
	
	--87781491
	--87941153
	
	
	--'87781491'
	--'87792839'
	--'87941145'
	--'87941146'
	--'87941153'
	--'40419401????????????????'
		
	
	
	
	--insert into @auditnos select '40419395';
	--insert into @auditnos select '40438713';
	--insert into @auditnos select '40438834';
	--insert into @auditnos select '40419383';
	--insert into @auditnos select '40419400';
	--insert into @auditnos select '40419401';
	--insert into @auditnos select '40419402';
	--insert into @auditnos select '40419405';
	--insert into @auditnos select '40419406';
	--insert into @auditnos select '40419407';
	--insert into @auditnos select '40419410';
	--insert into @auditnos select '40419430';
	--insert into @auditnos select '40419431';
	--insert into @auditnos select '40419434';
	--insert into @auditnos select '40419435';
	--insert into @auditnos select '40419518';
	--insert into @auditnos select '40419394';
	--insert into @auditnos select '40428693';
	--insert into @auditnos select '40429942';
	--insert into @auditnos select '40490532';
	--insert into @auditnos select '40490533';
	--insert into @auditnos select '40490534';
	--insert into @auditnos select '40490535';
	--insert into @auditnos select '40490536';
	--insert into @auditnos select '40490537';
	--insert into @auditnos select '40490538';
	--insert into @auditnos select '40490539';
	--insert into @auditnos select '40490540';
	--insert into @auditnos select '40490541';
	--insert into @auditnos select '40490542';
	--insert into @auditnos select '40490556';
	--insert into @auditnos select '40490678';
	--insert into @auditnos select '40491653';
	--insert into @auditnos select '40419437';
	--insert into @auditnos select '40419439';
	--insert into @auditnos select '40419440';
	--insert into @auditnos select '40419441';
	--insert into @auditnos select '40419442';
	--insert into @auditnos select '40419457';
	--insert into @auditnos select '60720424';

	declare links_cursor cursor for
		select * from @auditnos;

	open links_cursor

	fetch next from links_cursor into @auditno
	begin tran
		while @@FETCH_STATUS = 0 
		begin
			select @drtcnt = count(*) from drt where drt_auditno = @auditno;
			select @drthistcnt = count(*) from drt_hist where drt_auditno = @auditno;
			if @drthistcnt > 0 or @drtcnt > 0
			begin
				print 'Processing Link No: ' + @auditno;

				-- Is the transaction in drt_hist
				-- If the tran is in hist it needs to be
				-- moved to drt, deleted from hist and
				-- unallocated in drt
				
				set @drthistcnt = 0;
				select @drthistcnt = count(*) from drt_hist where drt_auditno = @auditno;
				if @drthistcnt > 0
				begin
					print 'Moving ' + @auditno + ' from drt_hist to drt';
					insert into drt( drt_fk_accno, drt_fk_trans, drt_auditno, drt_gllink, drt_alloc, drt_agecode, drt_ref, drt_date, drt_debit, drt_credit, drt_ivat, drt_type, drt_deal, drt_regno, 
							drt_month, drt_unum, drt_udatetime, drt_company, drt_acbcollect, drt_agrno, drt_billbatch, drt_allocdate, drt_fk_branch, drt_fk_reasoncode, drt_fk_acbcreatedate, drt_fk_acbactiondate, 
							drt_fk_acbusercode, drt_fk_acbusergenno, drt_fk_acbuserseqno ) 
						select drt_fk_accno, drt_fk_trans, drt_auditno, drt_gllink, drt_alloc, drt_agecode, drt_ref, drt_date, drt_debit, drt_credit, drt_ivat, drt_type, drt_deal, drt_regno, drt_month, 
								drt_unum, drt_udatetime, drt_company, drt_acbcollect, drt_agrno, drt_billbatch, drt_allocdate, drt_fk_branch, drt_fk_reasoncode, drt_fk_acbcreatedate, drt_fk_acbactiondate, 
								drt_fk_acbusercode, drt_fk_acbusergenno, drt_fk_acbuserseqno 
					from drt_hist 
					where drt_auditno = (select drt_auditno from drt_hist where drt_auditno = @auditno )
					print 'Deleting ' + @auditno + ' from drt_hist'
					delete drt_hist where drt_auditno = @auditno
				end
		
				print 'Unallocating ' + @auditno;
				update drt 
					set drt_agecode = dbo.fn_GetAgeCode( datediff( d, drt_date, sysdatetime() ) ), 
					drt_alloc = 0, 
					drt_allocdate = NULL
				where drt_auditno = @auditno
			end
			update DebtorTranLink set ActiveInd = 0 where Master_AuditNo = @auditno or Detail_AuditNo = @auditno;
			fetch next from links_cursor into @auditno
		end
	commit tran
	close links_cursor

	set nocount on;
	declare @type varchar(20);
	declare @alloc int;
	open links_cursor
	fetch next from links_cursor into @auditno
	while @@FETCH_STATUS = 0 
	begin
		select @drtcnt = count(*) from drt where drt_auditno = @auditno;
		if @drtcnt > 0
		begin
			set @counter = @counter + 1;
			select @type = drt_fk_trans, @alloc = drt_alloc from drt where drt_auditno = @auditno
			print 'Audit no: ' + @auditno + ', Trans Type: ' + @type + ', Allocated: ' + cast(@alloc as varchar(20));
		end
		fetch next from links_cursor into @auditno;
	end
	close links_cursor;
	deallocate links_cursor;

	print 'Processed ' + cast(@counter as varchar(20)) + ' records';

end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------MMMMMMMMMMMM
--declare @db varchar(50) = (select db_name())


--if @db like 'FleetActiv_Imperial%'
begin

			select * from drt_drt_hist_cc
			where  drt_gllink IN 
			(
				
				'89165714',
				'89193079',
				'89578399',
                '89578389',
                '89578388'--,
			
			)

			SELECT * from 
			drt_drt_hist_cc
			where drt_fk_accno = '011428' and drt_gllink = '89578399'
			
			--select * from Func_DR_Linked_Transactions('87941145')

			--select * from DebtorTranLink
			--where Master_AuditNo = '87941153'
			--or Detail_AuditNo = '87941153'


			--select * from DebtorTranLink
			--where Detail_AuditNo = '87941153'

			--select * from crt
			--where crt_fk_accno = '011428'

			--select * from drt
			--where drt_gllink = '89578399'


----------------------------------------
	  --      select * from crt
			--where crt_fk_accno = '011428'
			
			--select * from drt_hist
			--where drt_gllink = '89578399'
			
			select * from drt_hist
			where drt_fk_accno = '011428' 
			order by drt_auditno desc
			
/*
011428   RECEIPT  87941153 89578399
011428   REV REC  87941146 89578389
011428   REV REC  87941145 89578388
		*/
------------------------------------------	
/*87941153
87941146
87941145
==
89578399
89578389
89578388

===
87941153
87941145
87941146

*/			

			select * from drt_hist
			where drt_ref = 'TSHEOLA DINARE TOURS'			
			order by drt_auditno desc	

			select * from drt_drt_hist_cc
			where drt_ref = 'TSHEOLA DINARE TOURS'			
			order by drt_auditno desc	
			
			--select * from drt_drt_hist_cc
			--where drt_ref = 'X3 FIX CORRE'			
			--order by drt_auditno desc
			
			--

			select * from DebtorTranLink
			where Master_AuditNo like '87941146' or 
			Detail_AuditNo like '87941146'
		
		
		
			select * from Func_DR_Linked_Transactions('87941145') ORDER by drt_auditno asc



			select * from DebtorTranLink
			where Master_AuditNo like '87941153' or 
			Detail_AuditNo like '87941153'
			
		 --   select * from crt
			--where crt_fk_accno = '011428'
			
			
			
			--select * from drt_drt_hist_cc
			--where drt_fk_accno = '011428' and 
			--drt_gllink like '89578388'
			
			----------------------------------------------87792839  87941145 87781491
			
			----select * from Func_DR_Linked_Transactions('87792839')--44.63
			
			
   --         drt_auditno
   --         87792839
   --         87941146
			
			----select * from DebtorTranLink
			----where Master_AuditNo like '87792839' or 
			----Detail_AuditNo like '87792839'
			
		 ----  --87941146
		
		
		
			
		 --   select * from crt
			--where crt_fk_accno = '011428'



   ----         select * from drt_drt_hist_cc
			----where drt_fk_accno = '011428'		
			------order by drt_auditno desc	
			----and drt_gllink = '89578399'


            select * from drt_drt_hist_cc
			where drt_fk_accno = '011428'		
			order by drt_auditno desc	
			--and drt_gllink = '89578399'
			
	------87941153 87941146 87941145
	------87792839 87941146   nbnbnbnbnbnbnb
			
			
			
   --         select * from DebtorTranLink
			--where Master_AuditNo = '87941153'
			--or Detail_AuditNo = '87941153'
			
	----------------------
	
	 
			--UPDATE drt
			--SET drt_alloc = 0-- 'N'
			--where drt_auditno = ''
			
			
			----select * from DebtorTranLink
			----where Master_AuditNo like '%879415%' or 
			----Detail_AuditNo like '87792839'
		
			
			---------------

			
--87781491
--87792839
--87941145
--87941146
--87941153
----------------------------------------
--89165714
--89193079
--89578388
--89578389
--89578399
			

			

			
		 
			
			

			
			
			
			
			--SELECT * from 
			--drt_drt_hist_cc 
			

end





