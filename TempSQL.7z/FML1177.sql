declare @userName varchar(30)
declare @userDesc varchar(100)
declare @serverName varchar(255) = 'WSBR3TFARDS1'


declare @userList table (
	userName varchar(30),
	userDesc  varchar(100)
)

insert into @userList
	select '63266203', 'vvanstaden'



declare userCursor cursor for
	select userName, userDesc
	from @userList

open userCursor
fetch next from userCursor into @userName, @userDesc
while @@fetch_status = 0
begin
	declare @userid int = isnull( ( select sum_id from suma where sum_name = @userName ), -9999 )

	if( @userid = -9999 )
	begin
		set @userid = ( select ( max( sum_id ) + 1 ) from suma )
	end	
	
	print 'Setting up access for ' + @userName + ' User ID = ' + cast( @userid as varchar(10) )

	if not exists ( select * from suma where sum_name = @userName )
	begin
		print 'Inserting new user'
	
		insert into suma ( 
			[sum_name],[sum_id],[sum_group],[sum_fullname],[sum_reset],[sum_active],[sum_auth_limit], [sum_dormant]
		) values (
			@userName, @userid, 0, @userDesc, 0, 1, 0, 0
		)
	end
	else
	begin
		print 'Updating current user'

		update suma
		set sum_dormant = 0,
			sum_active = 1 
		where sum_id = @userid
	end


	insert into sus (
		sus_fk_id,sus_fk_statcode,sus_statdate
	)values (
		@userid, 'ACT', GETDATE()
	)

	print 'Granting user access to menu items and components'
	delete from sua where sua_id = @userid
	delete from suc where suc_id = @userid

	insert into sua ( 
			sua_id, sua_module, sua_menu_id, sua_grant 
			)
		select @userid, sua_module, sua_menu_id, sua_grant
		from sua
		where sua_id = '1'

	insert into suc 
		select suc_comp_id, @userid, suc_module, suc_menu_id, suc_order, suc_grant	
		from suc
		where suc_id = '1'		


	if not exists ( select * from uact where uact_fk_uid = @userid and uact_compname = @serverName)
	begin
		print 'Inserting UACT entry for user / QA Application server'

		insert into uact ( 
			uact_fk_uid,uact_compname,uact_lastlogin
		) values (
			@userid, @serverName, GETDATE()
		)
	end
	else
	begin
		print 'Updating UACT entry for user'

		update uact 
		set uact_lastlogin = GETDATE()
		where uact_fk_uid = @userid 
		and uact_compname = @serverName
	end

	fetch next from userCursor into @userName, @userDesc
end

close userCursor
deallocate userCursor