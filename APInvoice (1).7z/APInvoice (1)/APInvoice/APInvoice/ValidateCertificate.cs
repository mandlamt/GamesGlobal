﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace APInvoice
{
    class ValidateCertificate
    {
        public bool isCertValid()
        {
            X509Certificate2 cert = null;
            try
            {
                cert = new X509Certificate2(@"C:\temp\debtreview.wesbank.co.za.pfx", "38&Z:5P%HlQv");
                // Use certificate here.

            }
            catch (Exception ex) 
            { 
            
            } // Handle exception please.
            finally
            {
                if (cert != null)
                {
                    // This method can be used to reset the state of the certificate. It also frees any resources associated with the certificate.
                    cert.Reset();
                    cert = null;
                }
            }
            return true;
        }
    }
}
