﻿using System;
using System.IO;
using System.Xml;
using System.Linq;
using System.Text;
using System.Data;
using System.Timers;
using System.Xml.Linq;
using System.Reflection;
using System.Configuration;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.ServiceModel.Dispatcher;
using System.ServiceModel.Description;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;

namespace APInvoice
{
    public class Globals
    {
        public static int APInvoiceTimeout = 0;
    }

    public class MessageInspectorBehavior : IClientMessageInspector, IEndpointBehavior
    {
        public event EventHandler OnMessageInspected;

        public string str_request = null;
        public string str_response = null;

        public void AfterReceiveReply(ref System.ServiceModel.Channels.Message reply, object correlationState)
        {
            if (OnMessageInspected != null)
            {
                str_response = reply.ToString();
            }
        }
        public object BeforeSendRequest(ref System.ServiceModel.Channels.Message request, System.ServiceModel.IClientChannel channel)
        {
            if (OnMessageInspected != null)
            {
                str_request = request.ToString();
            }
            return null;
        }
        public void AddBindingParameters(ServiceEndpoint endpoint, System.ServiceModel.Channels.BindingParameterCollection bindingParameters)
        {
        }
        public void ApplyClientBehavior(ServiceEndpoint endpoint, ClientRuntime clientRuntime)
        {
            clientRuntime.MessageInspectors.Add(this);
        }
        public void ApplyDispatchBehavior(ServiceEndpoint endpoint, EndpointDispatcher endpointDispatcher)
        {
        }
        public void Validate(ServiceEndpoint endpoint)
        {
        }


    }



    //----------------------------------------------------------------------------------------------------------
    class Program
    {
        static bool App_CertificateValidation(Object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
        {
            if (sslPolicyErrors == SslPolicyErrors.None)
            {
                return true;
            }
            if (sslPolicyErrors == SslPolicyErrors.RemoteCertificateChainErrors)
            {
                return true;
            }
            return false;
        }

        static int Main(string[] args)
        {
            try
            {
                var clientCertificate = new X509Certificate2(@"C:\temp\wsbr3tfards1.pfx", "y8!$dAZSmPRLt");
                var clientCertificateCollection = new X509CertificateCollection(new X509Certificate[] { clientCertificate });

                using (var client = new TcpClient("osbsqa.wesbank.co.za", 443))

                using (var sslStream = new SslStream(client.GetStream(), false, App_CertificateValidation))
                {
                    sslStream.AuthenticateAsClient("osbsqa.wesbank.co.za", clientCertificateCollection, SslProtocols.Tls12, false);

                    if (sslStream.IsMutuallyAuthenticated)
                    {
                        Console.WriteLine("Connected to ......" + client.Client.RemoteEndPoint);
                        //add the payment code here

                        string arg_auditno = null;
                        string arg_datasource = null;
                        string arg_catalog = null;
                        string conn_str = null;

                        try
                        {
                            arg_auditno = args[0];
                            arg_datasource = args[1];
                            arg_catalog = args[2];

                            LogWriter("starting apinvoice...", arg_catalog);
                            LogWriter("args[0]=" + arg_auditno, arg_catalog);
                            LogWriter("args[1]=" + arg_datasource, arg_catalog);
                            LogWriter("args[2]=" + arg_catalog, arg_catalog);
                        }
                        catch (Exception e)
                        {
                            LogWriter(e.Message, arg_catalog);
                            LogWriter("3 command line arguments must be supplied - [auditno, datasource, catalog] - apinvoice will terminate", arg_catalog);
                            return 1;
                        }

                        conn_str = "Data Source=" + arg_datasource + ";";
                        conn_str += "Initial Catalog=" + arg_catalog + ";";
                        conn_str += "Integrated Security=SSPI;";

                        LogWriter("connectionstring=" + conn_str, arg_catalog);

                        SqlConnection sql_conn = new SqlConnection(conn_str);
                        SqlCommand sql_cmd = new SqlCommand();
                        SqlTransaction sql_tran = null;

                        string[] column;
                        int cnt = 0;

                        try
                        {
                            LogWriter("connecting to:" + arg_datasource + ":" + arg_catalog, arg_catalog);
                            sql_conn.Open();
                            LogWriter("connection successful", arg_catalog);
                            sql_cmd.Connection = sql_conn;
                            sql_cmd.CommandText = "exec dbo.getapinvoicedetails '" + arg_auditno + "'";

                            LogWriter(sql_cmd.CommandText, arg_catalog);

                            using (var reader = sql_cmd.ExecuteReader())
                            {
                                column = new string[reader.FieldCount];

                                if (reader.HasRows)
                                {
                                    while (reader.Read())
                                    {
                                        cnt++;
                                        for (int i = 0; i < reader.FieldCount; i++)
                                        {
                                            try { column[i] = reader.GetString(i); }
                                            catch (Exception) { column[i] = null; continue; }
                                        }
                                    }
                                    if (cnt == 1)
                                    {
                                        LogWriter("success - one record returned from stored procedure dbo.getapinvoicedetails", arg_catalog);
                                    }
                                }
                                else
                                {
                                    LogWriter("empty reult set returned from stored procedure dbo.getapinvoicedetails - apinvoice will terminate", arg_catalog);
                                    sql_conn.Close();
                                    return 2;
                                }

                                if (cnt > 1)
                                {
                                    LogWriter("more than one record returned from stored procedure dbo.getapinvoicedetails - apinvoice will terminate", arg_catalog);
                                    sql_conn.Close();
                                    return 3;
                                }
                            }

                            sql_conn.Close();
                        }
                        catch (Exception ex)
                        {
                            LogWriter(ex.Message + " - apinvoice will terminate", arg_catalog);
                            sql_conn.Close();
                            return 4;
                        }

                        APInvoice.APInvoiceServiceRef.supplierType supplierDetails = new APInvoice.APInvoiceServiceRef.supplierType();
                        APInvoice.APInvoiceServiceRef.invoiceType invoiceDetails = new APInvoice.APInvoiceServiceRef.invoiceType();

                        //-----------------------------------------------------------------------------------------
                        //sht param4 - supplierheadertype
                        //-----------------------------------------------------------------------------------------

                        APInvoice.APInvoiceServiceRef.supplierHeaderType sht = new APInvoice.APInvoiceServiceRef.supplierHeaderType();

                        sht.supplierName = column[0];
                        sht.supplierAltName = column[1];
                        sht.supplierVATregNumber = column[2];
                        sht.typeOfSupplier = (APInvoiceServiceRef.typeOfSupplierType)Enum.Parse(typeof(APInvoiceServiceRef.typeOfSupplierType), column[3]);
                        sht.supplierCustNumber = column[4];

                        //-----------------------------------------------------------------------------------------
                        //sst param4 - suppliersitetype
                        //-----------------------------------------------------------------------------------------

                        APInvoice.APInvoiceServiceRef.supplierSiteType sst = new APInvoice.APInvoiceServiceRef.supplierSiteType();

                        sst.customerNumber = column[5];
                        sst.orgID = Convert.ToDecimal(column[6]);
                        sst.supplierSiteCode = column[7];
                        sst.addressLine1 = column[8];
                        sst.addressLine2 = column[9];
                        sst.addressLine3 = column[10];
                        sst.city = column[11];
                        sst.postalCode = column[12];
                        sst.country = column[13];
                        sst.areaCode = column[14];
                        sst.phoneNumber = column[15];
                        sst.faxNumber = column[16];
                        sst.faxAreaCode = column[17];
                        sst.remittance = (APInvoiceServiceRef.remittanceType)Enum.Parse(typeof(APInvoiceServiceRef.remittanceType), column[18]);
                        sst.remittanceEmail = column[19];
                        sst.remitAdviceDeliveryMethod = column[20];
                        sst.bankName = column[21];
                        sst.branchName = column[22];
                        sst.branchCode = column[23];
                        sst.bankAccountName = column[24];
                        sst.bankAccountNumber = column[25];
                        sst.primaryAccountFlag = (APInvoiceServiceRef.primaryAccountFlagType)Enum.Parse(typeof(APInvoiceServiceRef.primaryAccountFlagType), column[26]);
                        sst.typeOfbankAccount = column[27];
                        sst.attributeCategory = column[28];
                        sst.attribute1 = column[29];
                        sst.attribute2 = column[30];
                        sst.attribute3 = column[31];
                        sst.attribute4 = column[32];
                        sst.attribute5 = column[33];
                        sst.attribute6 = column[34];
                        sst.attribute7 = column[35];
                        sst.attribute8 = column[36];
                        sst.attribute9 = column[37];
                        sst.attribute10 = column[38];

                        //------------------------------------------------------------------------------------------
                        //iht param5 - invoiceheadertype
                        //------------------------------------------------------------------------------------------

                        APInvoice.APInvoiceServiceRef.invoiceHeaderType iht = new APInvoice.APInvoiceServiceRef.invoiceHeaderType();

                        iht.orgIdHeader = Convert.ToDecimal(column[39]);
                        iht.customerNumber = column[40];
                        iht.supplierSiteCode = column[41];
                        iht.payGroupLookupCode = column[42];
                        iht.exclusivePaymentFlag = (APInvoiceServiceRef.exclusivePaymentFlagType)Enum.Parse(typeof(APInvoiceServiceRef.exclusivePaymentFlagType), column[43]);
                        iht.invoiceNumber = column[44];
                        iht.uniqueRemittanceIndetifier = column[45];
                        iht.invoiceTypeLookupCode = (APInvoiceServiceRef.invoiceTypeLookupCodeType)Enum.Parse(typeof(APInvoiceServiceRef.invoiceTypeLookupCodeType), column[46]);
                        iht.invoiceDate = Convert.ToDateTime(column[47]);
                        iht.nwsfLobDate = Convert.ToDateTime(column[48]);
                        iht.invoiceAmount = Convert.ToDecimal(column[49]);
                        iht.invoiceCurrencyCode = column[50];
                        iht.headerDescription = column[51];
                        iht.paymentTerms = column[52];
                        iht.attributeCategory = column[53];
                        iht.attribute1 = column[54];
                        iht.attribute2 = column[55];
                        iht.attribute11 = column[56];

                        APInvoice.APInvoiceServiceRef.invoiceLineType ilt = new APInvoice.APInvoiceServiceRef.invoiceLineType();

                        ilt.customerNumber = column[57];
                        ilt.supplierSiteCode = column[58];
                        ilt.invoiceNumber = column[59];
                        ilt.invLineNumber = Convert.ToDecimal(column[60]);
                        ilt.lineTypeLookupCode = (APInvoiceServiceRef.lineTypeLookupCodeType)Enum.Parse(typeof(APInvoiceServiceRef.lineTypeLookupCodeType), column[61]);  //0; //ITEM
                        ilt.amount = Convert.ToDecimal(column[62]);
                        ilt.vatCode = column[63];
                        ilt.distributionSet = column[64];
                        ilt.quantityInvoiced = Convert.ToDecimal(column[65]);

                        APInvoice.APInvoiceServiceRef.invoiceLineType[] ilt_arr = new APInvoiceServiceRef.invoiceLineType[1];

                        ilt_arr[0] = ilt;
                        iht.invoiceLines = ilt_arr;

                        //-------------------------------------------------------------------------------------------------------------
                        supplierDetails.supplierHeader = sht;
                        supplierDetails.supplierSite = sst;
                        invoiceDetails.invoiceHeader = iht;

                        //-------------------------------------------------------------------------------------------------------------

                        MessageInspectorBehavior MessageInspector = new MessageInspectorBehavior();

                        int submitType = 2; //Oracle APInvoice Submissions
                        int wait = 0;
                        int batchNo = Int32.Parse(column[66]);
                        int respondTime = 0;
                        int timeoutValue = 0;

                        try
                        {
                            timeoutValue = Int32.Parse(ConfigurationManager.AppSettings["APInvoiceTimeOut"]);
                        }
                        catch (Exception) { timeoutValue = 30; }

                        string batchSource = column[64];
                        string transactionType = column[67];
                        string tradingPartner = column[68];

                        try
                        {
                            APInvoice.APInvoiceServiceRef.APInvoiceRequest apinv_request = new APInvoice.APInvoiceServiceRef.APInvoiceRequest
                            (Convert.ToDecimal(arg_auditno), transactionType, tradingPartner, supplierDetails, invoiceDetails);



                            APInvoice.APInvoiceServiceRef.APinvoiceClient call = new APInvoice.APInvoiceServiceRef.APinvoiceClient();
                            call.Endpoint.EndpointBehaviors.Add(MessageInspector);

                            MessageInspector.OnMessageInspected += (src, e) => { };

                            LogWriter("calling apinvoiceclient()...", arg_catalog);

                            call.APInvoiceAsync(apinv_request);

                            LogWriter("xml request:\r\n\r\n" + MessageInspector.str_request + "\r\n", arg_catalog);

                            System.Timers.Timer tmrTimeout = new System.Timers.Timer(1000);
                            tmrTimeout.Elapsed += OnTimedEvent;
                            tmrTimeout.AutoReset = true;
                            tmrTimeout.Enabled = true;

                            while (MessageInspector.str_response == null)
                            {
                                wait++;

                                if (APInvoice.Globals.APInvoiceTimeout > timeoutValue)
                                {
                                    respondTime = APInvoice.Globals.APInvoiceTimeout;
                                    break;
                                }
                            }

                            call.Close();
                            tmrTimeout.Enabled = false;

                            if ((respondTime > timeoutValue) && string.IsNullOrEmpty(MessageInspector.str_response))
                            {
                                LogWriter("apinvoice timeout. check config file to increase the timeout value", arg_catalog);
                                return 12;
                            }

                            LogWriter("xml response:\r\n\r\n" + MessageInspector.str_response + "\r\n", arg_catalog);

                            XmlDocument doc = new XmlDocument();
                            XmlNamespaceManager manager = new XmlNamespaceManager(doc.NameTable);
                            manager.AddNamespace("apin", "http://www.wesbank.co.za/wesbank/bus/Payments/APinvoice/v1_0/xsd/APinvoice");

                            doc.LoadXml(MessageInspector.str_response);

                            int preValidateFailed = 0;
                            string status = null;
                            string msg = null;


                            var elemList = doc.SelectNodes("//apin:supplierHeaderMessage", manager);
                            foreach (XmlNode node in elemList)
                            {
                                status = node.SelectSingleNode("apin:status", manager).InnerText;
                                msg = node.SelectSingleNode("apin:message", manager).InnerText;
                            }
                            if (status != "S" && !string.IsNullOrEmpty(status)) { preValidateFailed = 1; }
                            //-------------------------------------------------------------------------------------
                            var elemList1 = doc.SelectNodes("//apin:supplierSiteMessage", manager);
                            foreach (XmlNode node in elemList1)
                            {
                                status = node.SelectSingleNode("apin:status", manager).InnerText;
                                msg = node.SelectSingleNode("apin:message", manager).InnerText;
                            }
                            if (status != "S" && !string.IsNullOrEmpty(status)) { preValidateFailed = 1; }
                            //-------------------------------------------------------------------------------------
                            var elemList2 = doc.SelectNodes("//apin:invoiceHeaderHeaderMessage", manager);
                            foreach (XmlNode node in elemList2)
                            {
                                status = node.SelectSingleNode("apin:status", manager).InnerText;
                                msg = node.SelectSingleNode("apin:message", manager).InnerText;
                            }
                            if (status != "S" && !string.IsNullOrEmpty(status)) { preValidateFailed = 1; }
                            //-------------------------------------------------------------------------------------
                            var elemList3 = doc.SelectNodes("//apin:invoiceLineMessage/apin:messageStatus", manager);
                            foreach (XmlNode node in elemList3)
                            {
                                status = node.SelectSingleNode("apin:status", manager).InnerText;
                                msg = node.SelectSingleNode("apin:message", manager).InnerText;
                            }
                            if (status != "S" && !string.IsNullOrEmpty(status)) { preValidateFailed = 1; }
                            //-------------------------------------------------------------------------------------
                            var elemList4 = doc.SelectNodes("//apin:messageStatus", manager);
                            foreach (XmlNode node in elemList4)
                            {
                                status = node.SelectSingleNode("apin:status", manager).InnerText;
                                msg = node.SelectSingleNode("apin:message", manager).InnerText;
                            }
                            if (status != "S" && !string.IsNullOrEmpty(status)) { preValidateFailed = 1; }
                            //-------------------------------------------------------------------------------------


                            if (status != "S" || preValidateFailed == 1)
                            {
                                LogWriter("pre-validation failed.", arg_catalog);
                                LogWriter("updating oraap tables with apinvoice request and response", arg_catalog);

                                if (!UpdateOraapFile(sql_conn, sql_cmd, sql_tran, MessageInspector.str_request, batchNo, batchSource, "PAYMENT_FILE", submitType, arg_catalog)) //update oraap_file with xml request
                                    return 5;

                                if (!UpdateOraapBatchAndTrans(sql_conn, sql_cmd, sql_tran, batchNo, batchSource, status, msg, submitType, arg_catalog))
                                    return 6;

                                if (!InsertOraapFile(sql_conn, sql_cmd, sql_tran, MessageInspector.str_response, batchNo, batchSource, "VALIDATE_FILE", submitType, arg_catalog)) //insert oraap_file with xml response
                                    return 7;

                                LogWriter("update oraap tables success.", arg_catalog);
                                return 8;
                            }

                            if (status == "S" && preValidateFailed == 0)
                            {
                                LogWriter("pre-validation success.", arg_catalog);
                                LogWriter("updating oraap tables with apinvoice request and response", arg_catalog);

                                if (!UpdateOraapFile(sql_conn, sql_cmd, sql_tran, MessageInspector.str_request, batchNo, batchSource, "PAYMENT_FILE", submitType, arg_catalog)) //update oraap_file with xml request
                                    return 9;

                                if (!UpdateOraapBatchAndTrans(sql_conn, sql_cmd, sql_tran, batchNo, batchSource, status, msg, submitType, arg_catalog))
                                    return 10;

                                if (!InsertOraapFile(sql_conn, sql_cmd, sql_tran, MessageInspector.str_response, batchNo, batchSource, "VALIDATE_FILE", submitType, arg_catalog)) //insert oraap_file with xml response
                                    return 11;

                                LogWriter("update oraap tables success.", arg_catalog);
                            }

                        }



                        catch (Exception ex)
                        {
                            LogWriter(ex.Message + " - apinvoice will terminate", arg_catalog);
                            return 12;
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                throw;
            }
            return 0; //success        
        }

        //------------------------------------------------------------------------------------------------
        private static string m_exePath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);

        public static void LogWriter(string logMessage, string instance)
        {
            LogWrite(logMessage, instance);
        }
        //------------------------------------------------------------------------------------------------
        public static void LogWrite(string logMessage, string instance)
        {
            try
            {
                using (StreamWriter w = File.AppendText(m_exePath + "\\" + "APInvoice_" + (string.IsNullOrEmpty(instance) ? "Error" : instance) + ".log"))
                {
                    Log(logMessage, w);
                }
            }
            catch (Exception ex) { Console.WriteLine(ex.Message); return; }
        }
        //------------------------------------------------------------------------------------------------
        public static void Log(string logMessage, TextWriter txtWriter)
        {
            try
            {
                txtWriter.WriteLine(DateTime.Now.ToString() + " -> " + logMessage);
            }
            catch (Exception ex) { Console.WriteLine(ex.Message); return; }
        }
        //------------------------------------------------------------------------------------------------
        public static bool UpdateOraapFile(SqlConnection sqlconn, SqlCommand sqlcmd, SqlTransaction sqltran, string xmlRequest, int batchNo, string batchSource, string fileType, int submitType, string catalog)
        {
            try
            {
                sqlconn.Open();
                sqlcmd.Connection = sqlconn;
                sqltran = sqlconn.BeginTransaction();
                sqlcmd.Transaction = sqltran;

                sqlcmd.CommandText = "update oraap_file ";
                sqlcmd.CommandText += "set fileBlob = '" + xmlRequest + "' ";
                sqlcmd.CommandText += "where fk_batchNo = " + batchNo + " ";
                sqlcmd.CommandText += "and fk_batchSource = '" + batchSource + "' ";
                sqlcmd.CommandText += "and fk_fileType = '" + fileType + "' ";
                sqlcmd.CommandText += "and fk_batchSubmitType = " + submitType;

                sqlcmd.ExecuteNonQuery();
                sqltran.Commit();
                sqlconn.Close();
                return true;
            }
            catch (Exception ex)
            {
                LogWriter("update oraap_file with apinvoice request failed - apinvoice will terminate", catalog);
                LogWriter(ex.Message, catalog);
                sqltran.Rollback();
                sqlconn.Close();
                return false;
            }
        }
        //------------------------------------------------------------------------------------------------
        public static bool UpdateOraapBatchAndTrans(SqlConnection sqlconn, SqlCommand sqlcmd, SqlTransaction sqltran, int batchNo, string batchSource, string stat, string msg, int submitType, string catalog)
        {
            try
            {
                sqlconn.Open();
                sqlcmd.Connection = sqlconn;
                sqltran = sqlconn.BeginTransaction();
                sqlcmd.Transaction = sqltran;

                string status = null;

                if (stat != "S")
                    status = "REJECTED";
                else
                    status = "VALIDATED";

                if (msg.Length > 200)               //oraap_batch -> errormessage varchar(200)
                    msg = msg.Substring(1, 200);

                sqlcmd.CommandText = "update oraap_batch set fk_batchStatus = '" + status + "', errorMessage = '" + msg + "' ";
                sqlcmd.CommandText += "where batchNo = " + batchNo + " and batchSource = '" + batchSource + "' and batchSubmitType = " + submitType;

                sqlcmd.CommandText += "\nupdate oraap_trans set fk_transStatus = '" + status + "', errorCode = '" + stat + "', errorMessage = '" + msg + "', acknowledgemessage = 'VALIDATE' ";
                sqlcmd.CommandText += "where fk_batchNo = " + batchNo + " and fk_batchSource = '" + batchSource + "' and fk_batchSubmitType = " + submitType + " and fk_transType in ('INVOICE', 'CREDITOR')";

                sqlcmd.ExecuteNonQuery();
                sqltran.Commit();
                sqlconn.Close();
                return true;
            }
            catch (Exception ex)
            {
                LogWriter("update oraap tables failed - apinvoice will terminate", catalog);
                LogWriter(ex.Message, catalog);
                sqltran.Rollback();
                sqlconn.Close();
                return false;
            }
        }
        //----------------------------------------------------------------------------------------------- 
        public static bool InsertOraapFile(SqlConnection sqlconn, SqlCommand sqlcmd, SqlTransaction sqltran, string xmlResponse, int batchNo, string batchSource, string fileType, int submitType, string catalog)
        {
            try
            {
                sqlconn.Open();
                sqlcmd.Connection = sqlconn;
                sqltran = sqlconn.BeginTransaction();
                sqlcmd.Transaction = sqltran;

                xmlResponse = xmlResponse.Replace("'", "\""); //replace any single quotes in xml response with double quotes to handle sql insert.

                sqlcmd.CommandText = "insert into oraap_file ";
                sqlcmd.CommandText += "values('" + batchSource + "', " + batchNo + ", '" + fileType + "', 'XML', GETDATE(), '" + xmlResponse + "', 1, " + submitType + ")";

                sqlcmd.ExecuteNonQuery();
                sqltran.Commit();
                sqlconn.Close();
                return true;
            }
            catch (Exception ex)
            {
                LogWriter("insert oraap_file failed - apinvoice will terminate", catalog);
                LogWriter(ex.Message, catalog);
                sqltran.Rollback();
                sqlconn.Close();
                return false;
            }
        }
        //-----------------------------------------------------------------------------------------------
        public static void OnTimedEvent(Object source, ElapsedEventArgs e)
        {
            APInvoice.Globals.APInvoiceTimeout += 1;
        }
        //-----------------------------------------------------------------------------------------------
    }
}
