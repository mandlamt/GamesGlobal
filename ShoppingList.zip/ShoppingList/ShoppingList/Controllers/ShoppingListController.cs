﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Logging;


namespace ShoppingList.Controllers


{
    [Authorize]
    [ApiController]
    [Route("[controller]")]
    public class ShoppingListController : ControllerBase
    {
        private readonly ILogger<ShoppingListController> _logger;

        public ShoppingListController(ILogger<ShoppingListController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public IEnumerable<ShoppingItem> Get()
        {
            var userId = User.Claims.First(c => c.Type == "sub").Value;
            return _shoppingListRepository.GetByUserId(userId);
        }

        [HttpPost]
        public ShoppingItem Post([FromBody] ShoppingItem item)
        {
            var userId = User.Claims.First(c => c.Type == "sub").Value;
            item.UserId = userId;
            return _shoppingListRepository.Add(item);
        }

        [HttpPut("{id}")]
        public ShoppingItem Put(int id, [FromBody] ShoppingItem item)
        {
            var userId = User.Claims.First(c => c.Type == "sub").Value;
            if (item.UserId != userId)
            {
                throw new UnauthorizedAccessException();
            }

            return _shoppingListRepository.Update(item);
        }

        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            var userId = User.Claims.First(c => c.Type == "sub").Value;
            var item = _shoppingListRepository.GetById(id);
            //if (item..UserId != userId)
            //{
            //    throw new UnauthorizedAccessException();
            //}

            _shoppingListRepository.Delete(item);
        }
    }
}

namespace ShoppingList
{
    public class ShoppingItem
    {
        public string UserId { get; internal set; }
        public object Id { get; internal set; }
    }

    public class _shoppingListRepository
    {
        internal static ShoppingItem Add(ShoppingItem item)
        {
            throw new NotImplementedException();
        }

        internal static void Delete(object item)
        {
            throw new NotImplementedException();
        }

        internal static object GetById(int id)
        {
            throw new NotImplementedException();
        }

        internal static IEnumerable<ShoppingItem> GetByUserId(string userId)
        {
            throw new NotImplementedException();
        }

        internal static ShoppingItem Update(ShoppingItem item)
        {
            throw new NotImplementedException();
        }
    }
}