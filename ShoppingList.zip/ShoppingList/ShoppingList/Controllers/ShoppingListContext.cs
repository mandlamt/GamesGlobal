﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ShoppingList.Controllers
{
    public class ShoppingListContext
    {
        internal IEnumerable<object> ShoppingItems;

        internal Task SaveChangesAsync()
        {
            throw new NotImplementedException();
        }

        internal object Entry(ShoppingItem item)
        {
            throw new NotImplementedException();
        }
    }
}