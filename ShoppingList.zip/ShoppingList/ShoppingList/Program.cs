using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Google.Apis.Auth;
using Google.Apis.PeopleService;
using Google.Apis.Auth.OAuth2;
using Google.Apis.PeopleService.v1;
using Google.Apis.PeopleService.v1.Data;
using Google.Apis.Services;
using System.IO;
using System.Threading;

namespace ShoppingList
{
    public class Program
    {

    static async System.Threading.Tasks.Task Main(string[] args)
    {
        UserCredential credential;
        using (var stream = new FileStream("client_secret_768095602068-6buoh5t6l6763c4f1a0fb00at3hpvp7q.apps.googleusercontent.com.json", FileMode.Open, FileAccess.Read))
        {
                credential = await GoogleWebAuthorizationBroker.AuthorizeAsync(GoogleClientSecrets.FromStream(stream).Secrets,
                    new[] { PeopleServiceService.Scope.ContactsReadonly },
                    "user",
                    CancellationToken.None);










                //credential = await GoogleWebAuthorizationBroker.AuthorizeAsync(
                //Google.Apis.Auth.OAuth2.GoogleClientSecrets.Load(stream).Secrets,
                //new[] { PeopleServiceService.Scope.ContactsReadonly }, // Scopes you need
                //"user",
                //CancellationToken.None);
            }

        // Create the service
        var service = new PeopleServiceService(new BaseClientService.Initializer
        {
            HttpClientInitializer = credential,
            ApplicationName = "ShoppingList",
        });

        // Use the service to make authorized API requests
        // Example:
        var connections = service.People.Connections.List("people/me").Execute();
    }
}





    //        public static void Main(string[] args)
    //        {
    //            CreateHostBuilder(args).Build().Run();
    //        }

    //        public static IHostBuilder CreateHostBuilder(string[] args) =>
    //            Host.CreateDefaultBuilder(args)
    //                .ConfigureWebHostDefaults(webBuilder =>
    //                {
    //                    webBuilder.UseStartup<Startup>();
    //                });
}

