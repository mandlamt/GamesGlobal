﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShoppingList
{

    public class ApplicationUser : IdentityUser
    {
        // Add any additional user properties here
        public ICollection<ShoppingListItem> ShoppingListItems { get; set; }
    }

    public class ShoppingListItem
    {
        public int Id { get; set; }
        public string UserId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public byte[] ImageData { get; set; }
        // Add other properties as needed
        public ApplicationUser User { get; set; }
        public int Quantity { get; set; } // The quantity of the item

    }
}
